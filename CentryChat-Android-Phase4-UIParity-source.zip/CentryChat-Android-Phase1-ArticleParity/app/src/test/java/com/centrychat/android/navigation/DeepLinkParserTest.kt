package com.centrychat.android.navigation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Phase 3 — Unit tests for [DeepLinkParser].
 *
 * Verifies that every canonical CentryChat URL format is correctly parsed
 * into a [DeepLinkTarget], and that invalid / unrelated URLs return null
 * (no navigation — the user lands on the feed as usual).
 *
 * The parser is a pure Kotlin object (no Android framework dependencies)
 * so it can be unit-tested directly without Robolectric / MockK.
 *
 * URL formats covered (mirrors the AndroidManifest.xml intent-filters):
 *   - https://sentrychat.netlify.app/?post={postId}     → Post(postId)
 *   - https://sentrychat.netlify.app/articles/{id}      → Article(id)
 *   - centrychat://post/{id}                             → Post(postId)
 *   - centrychat://article/{id}                          → Article(id)
 */
class DeepLinkParserTest {

    @Test
    fun `https post URL with valid postId returns Post target`() {
        val target = DeepLinkParser.parseString("https://sentrychat.netlify.app/?post=abc123")
        assertEquals(DeepLinkTarget.Post("abc123"), target)
    }

    @Test
    fun `https article URL with valid articleId returns Article target`() {
        val target = DeepLinkParser.parseString("https://sentrychat.netlify.app/articles/article456")
        assertEquals(DeepLinkTarget.Article("article456"), target)
    }

    @Test
    fun `https post URL with empty postId returns null`() {
        val target = DeepLinkParser.parseString("https://sentrychat.netlify.app/?post=")
        assertNull(target)
    }

    @Test
    fun `https post URL with missing post param returns null`() {
        val target = DeepLinkParser.parseString("https://sentrychat.netlify.app/")
        assertNull(target)
    }

    @Test
    fun `https article URL with empty articleId returns null`() {
        val target = DeepLinkParser.parseString("https://sentrychat.netlify.app/articles/")
        assertNull(target)
    }

    @Test
    fun `https URL with non-sentrychat host returns null`() {
        val target = DeepLinkParser.parseString("https://centrychat.netlify.app/?post=abc123")
        assertNull(target)
    }

    @Test
    fun `https URL with unknown path returns null`() {
        val target = DeepLinkParser.parseString("https://sentrychat.netlify.app/profile/john")
        assertNull(target)
    }

    @Test
    fun `http URL is rejected (only https is auto-verified)`() {
        val target = DeepLinkParser.parseString("http://sentrychat.netlify.app/?post=abc123")
        assertNull(target)
    }

    @Test
    fun `centrychat custom-scheme post URL returns Post target`() {
        val target = DeepLinkParser.parseString("centrychat://post/abc123")
        assertEquals(DeepLinkTarget.Post("abc123"), target)
    }

    @Test
    fun `centrychat custom-scheme article URL returns Article target`() {
        val target = DeepLinkParser.parseString("centrychat://article/article456")
        assertEquals(DeepLinkTarget.Article("article456"), target)
    }

    @Test
    fun `centrychat custom-scheme with unknown host returns null`() {
        val target = DeepLinkParser.parseString("centrychat://profile/john")
        assertNull(target)
    }

    @Test
    fun `centrychat custom-scheme with empty path returns null`() {
        val target = DeepLinkParser.parseString("centrychat://post/")
        assertNull(target)
    }

    @Test
    fun `unknown scheme returns null`() {
        val target = DeepLinkParser.parseString("ftp://sentrychat.netlify.app/?post=abc123")
        assertNull(target)
    }

    @Test
    fun `article URL with trailing slash is accepted`() {
        val target = DeepLinkParser.parseString("https://sentrychat.netlify.app/articles/article456/")
        assertEquals(DeepLinkTarget.Article("article456"), target)
    }

    @Test
    fun `post URL with extra query params still extracts post`() {
        val target = DeepLinkParser.parseString("https://sentrychat.netlify.app/?post=abc123&ref=whatsapp&utm_source=share")
        assertEquals(DeepLinkTarget.Post("abc123"), target)
    }

    @Test
    fun `blank URL returns null`() {
        val target = DeepLinkParser.parseString("")
        assertNull(target)
    }

    @Test
    fun `URL without scheme returns null`() {
        val target = DeepLinkParser.parseString("sentrychat.netlify.app/?post=abc123")
        assertNull(target)
    }

    @Test
    fun `uppercase HTTPS scheme is accepted (case-insensitive)`() {
        val target = DeepLinkParser.parseString("HTTPS://sentrychat.netlify.app/?post=abc123")
        assertEquals(DeepLinkTarget.Post("abc123"), target)
    }

    @Test
    fun `uppercase host is accepted (case-insensitive)`() {
        val target = DeepLinkParser.parseString("https://SENTRYCHAT.NETLIFY.APP/?post=abc123")
        assertEquals(DeepLinkTarget.Post("abc123"), target)
    }
}
