package com.centrychat.android

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.core.theme.CentryChatTheme
import com.centrychat.android.navigation.CentryChatRoot
import com.centrychat.android.navigation.DeepLinkParser
import com.centrychat.android.navigation.DeepLinkTarget
import com.centrychat.android.navigation.LocalPendingDeepLink
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * The single launcher activity.
 *
 * Responsibilities:
 *  1. Installs the Android 12+ SplashScreen API (no-op on older versions,
 *     but the theme swap still happens via Theme.CentryChat.Splash).
 *  2. Enables edge-to-edge layout (status + navigation bars are transparent
 *     and tinted by [CentryChatTheme]).
 *  3. Mounts the Compose root — [CentryChatRoot] which contains the
 *     NavHost + auth gate + bottom navigation.
 *  4. Phase 3 — Handles incoming deep-link / App-Link intents.
 *     a. Cold start: the system launches MainActivity with the VIEW intent
 *        (e.g. https://sentrychat.netlify.app/articles/abc123). onCreate
 *        reads intent.data, parses it into a [DeepLinkTarget], and exposes
 *        it via [pendingDeepLink] BEFORE setContent so the NavHost can
 *        navigate to the right screen after the splash session check.
 *     b. Warm start: the system delivers the VIEW intent to the SAME
 *        instance (singleTop launchMode) via onNewIntent. We re-parse
 *        and update [pendingDeepLink] so the NavHost observes the new
 *        target via StateFlow + navigates accordingly.
 *
 * URL parsing rules (mirrors the website's canonical share URLs):
 *   - https://sentrychat.netlify.app/?post={postId}     → PostDetail(postId)
 *   - https://sentrychat.netlify.app/articles/{id}      → ArticleDetail(id)
 *   - centrychat://post/{id}                            → PostDetail(postId)
 *   - centrychat://article/{id}                         → ArticleDetail(id)
 *
 * Safety:
 *   - Invalid / malformed URLs → no navigation (the splash screen proceeds
 *     to the feed as usual). The user never sees a crash or black screen.
 *   - Invalid post/article IDs → navigate to PostDetail/ArticleDetail
 *     anyway; the ViewModel's loadPost/loadArticle will fail with a 404
 *     and the screen shows its ErrorState with a Retry button.
 *   - Logged-out user + deep link → the splash session check runs first;
 *     if the session is dead, the user is sent to LOGIN (the deep link is
 *     lost — same as the website's behavior when not logged in).
 */
class MainActivity : ComponentActivity() {

    /**
     * The pending deep-link target. Exposed to [CentryChatRoot] via the
     * [LocalPendingDeepLink] CompositionLocal. When non-null, the NavHost
     * navigates to the target screen + clears the flow (so the user can
     * press Back to leave the detail screen without re-triggering it).
     *
     * MutableStateFlow (not the read-only StateFlow) so CentryChatRoot
     * can clear it via `pendingDeepLinkFlow.value = null` after
     * consumption — preventing duplicate navigation triggers on every
     * recomposition.
     */
    private val _pendingDeepLink = MutableStateFlow<DeepLinkTarget?>(null)
    val pendingDeepLink: MutableStateFlow<DeepLinkTarget?> = _pendingDeepLink

    override fun onCreate(savedInstanceState: Bundle?) {
        // Install the splash-screen BEFORE super.onCreate — the splash
        // hand-off requires it to be the first thing set up.
        installSplashScreen()

        super.onCreate(savedInstanceState)

        // Edge-to-edge: content draws behind the system bars. The system bar
        // icons are tinted by the theme based on the current color scheme.
        enableEdgeToEdge()

        // Resolve the AppContainer from the application instance. We pass
        // it down only as far as necessary (the root Composable) so that
        // Compose code can construct ViewModels with their dependencies.
        val appContainer: AppContainer = (application as CentryChatApp).appContainer

        // Phase 3 — parse the intent that launched us. On cold start this
        // is the VIEW intent from a tapped link; on warm start it's null
        // here (onNewIntent handles it). We parse before setContent so
        // the NavHost can observe the StateFlow from the very first frame.
        handleDeepLinkIntent(intent)

        setContent {
            CompositionLocalProvider(
                LocalAppContainer provides appContainer,
                LocalPendingDeepLink provides _pendingDeepLink,
            ) {
                CentryChatTheme {
                    CentryChatRoot(appContainer = appContainer)
                }
            }
        }
    }

    /**
     * Phase 3 — handle warm-start deep links. When the activity is already
     * running (singleTop launchMode) and the user taps a CentryChat link
     * from another app, the system delivers the VIEW intent here instead
     * of creating a new activity instance.
     *
     * We re-parse the intent + update [_pendingDeepLink] so the NavHost
     * observes the new target + navigates accordingly.
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // setIntent so subsequent calls (e.g. onRestoreInstanceState) see
        // the new intent.
        setIntent(intent)
        handleDeepLinkIntent(intent)
    }

    /**
     * Parse a deep-link intent + extract the [DeepLinkTarget]. No-op if
     * the intent has no data URI or the URI doesn't match any known
     * CentryChat URL pattern.
     *
     * Accepted URL formats (see [DeepLinkParser]):
     *   - https://sentrychat.netlify.app/?post={postId}
     *   - https://sentrychat.netlify.app/articles/{articleId}
     *   - centrychat://post/{postId}
     *   - centrychat://article/{articleId}
     *
     * Anything else is silently ignored (the user lands on the feed).
     */
    private fun handleDeepLinkIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.action != Intent.ACTION_VIEW) return
        val data: Uri = intent.data ?: return

        val target = DeepLinkParser.parse(data) ?: return
        _pendingDeepLink.value = target
    }
}

