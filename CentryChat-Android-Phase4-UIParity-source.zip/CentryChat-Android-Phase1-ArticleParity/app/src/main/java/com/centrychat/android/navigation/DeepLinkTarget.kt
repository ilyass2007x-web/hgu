package com.centrychat.android.navigation

import androidx.compose.runtime.staticCompositionLocalOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Phase 3 — Discriminated deep-link target.
 *
 * Produced by [com.centrychat.android.MainActivity] when the app is launched
 * (or resumed) via an App-Link intent. Observed by [com.centrychat.android.navigation.CentryChatRoot]
 * which navigates to the appropriate detail screen after the splash session
 * check completes.
 *
 * URL formats (mirrors the website's canonical share URLs):
 *   - https://sentrychat.netlify.app/?post={postId}     → Post(postId)
 *   - https://sentrychat.netlify.app/articles/{id}      → Article(id)
 *   - centrychat://post/{id}                             → Post(postId)
 *   - centrychat://article/{id}                          → Article(id)
 */
sealed class DeepLinkTarget {
    /** Open PostDetailScreen for the given post ID. */
    data class Post(val postId: String) : DeepLinkTarget()

    /** Open ArticleDetailScreen for the given article ID. */
    data class Article(val articleId: String) : DeepLinkTarget()
}

/**
 * CompositionLocal providing the activity's pending-deep-link MutableStateFlow.
 *
 * Set by [com.centrychat.android.MainActivity] in [androidx.activity.ComponentActivity.setContent]
 * via [androidx.compose.runtime.CompositionLocalProvider]. Consumed by
 * [com.centrychat.android.navigation.CentryChatRoot] which observes the
 * MutableStateFlow + navigates to the appropriate detail screen when a
 * non-null target arrives.
 *
 * Exposing the MutableStateFlow (not just the read-only StateFlow) lets
 * CentryChatRoot CLEAR the target after consumption so Back navigation
 * works correctly (the user can pop the detail screen back to the feed
 * without re-triggering the deep link on every recomposition).
 */
val LocalPendingDeepLink = staticCompositionLocalOf<MutableStateFlow<DeepLinkTarget?>> {
    error("LocalPendingDeepLink not provided")
}

