package com.centrychat.android.feature.feed

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.PaginatedState
import com.centrychat.android.data.model.FeedItemDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.repository.AuthRepository
import com.centrychat.android.data.repository.FeedRepository
import com.centrychat.android.data.repository.PostsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * The unified home feed ViewModel.
 *
 * Pulls the personalized feed from the backend (no client-side ranking —
 * the recommendation algorithm lives entirely in the backend). Supports:
 *   - Initial load
 *   - Pull-to-refresh
 *   - Infinite scroll (load more)
 *   - Inline "What's Happening?" composer create-post (Phase 4 parity)
 */
class FeedViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: FeedRepository = appContainer.feedRepository
    private val authRepo: AuthRepository = appContainer.authRepository
    /** Used by the inline HomeComposer to create posts (POST /api/v1/posts). */
    private val postsRepo: PostsRepository = appContainer.postsRepository

    private val _state = MutableStateFlow<PaginatedState<FeedItemDto>>(PaginatedState())
    val state: StateFlow<PaginatedState<FeedItemDto>> = _state

    /** Inline-composer transient UI events (snackbar for create success/error). */
    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val events: SharedFlow<String> = _events.asSharedFlow()

    init {
        // Auto-load the first page when the ViewModel is created.
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null, endReached = false)
            try {
                val response = repo.getForYou(limit = 20)
                _state.value = PaginatedState(
                    items = response.items,
                    cursor = response.nextCursor,
                    isLoading = false,
                    endReached = response.nextCursor == null,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Fallback: if the personalized feed fails (e.g. user has no
                // follow graph yet), try the trending feed.
                try {
                    val trending = repo.getTrending(limit = 20)
                    _state.value = PaginatedState(
                        items = trending.items,
                        cursor = trending.nextCursor,
                        isLoading = false,
                        endReached = trending.nextCursor == null,
                    )
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (_: Exception) {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = e.message ?: "Could not load feed.",
                    )
                }
            }
        }
    }

    fun loadMore() {
        val current = _state.value
        if (current.isLoadingMore || current.endReached || current.cursor == null) return

        viewModelScope.launch {
            _state.value = current.copy(isLoadingMore = true)
            try {
                val next = repo.getForYouNext(cursor = current.cursor!!, limit = 20)
                _state.value = current.copy(
                    items = current.items + next.items,
                    cursor = next.nextCursor,
                    isLoadingMore = false,
                    endReached = next.nextCursor == null,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = current.copy(
                    isLoadingMore = false,
                    error = e.message,
                )
            }
        }
    }

    /**
     * Phase 4 parity — Inline "What's Happening?" composer create-post.
     *
     * Mirrors the website's `HomeComposer.submit()` at
     * `src/components/posts/home-composer.tsx:73-95`:
     *   - Calls POST /api/v1/posts with the trimmed content
     *   - On success: prepends the new post to the feed (no full re-fetch)
     *     + dispatches a success snackbar
     *   - On failure: keeps the text in the composer (caller's job) +
     *     dispatches an error snackbar
     *
     * The composer is the inline UI at the top of the feed (collapsed
     * "What's happening?" → expands to textarea + Post button on tap),
     * matching the website. The previous FAB was removed because it was
     * the duplicate entry point.
     */
    fun createPost(content: String) {
        if (content.isBlank()) return
        viewModelScope.launch {
            try {
                val newPost = postsRepo.createPost(content = content.trim())
                // Prepend the new post to the feed (no full re-fetch —
                // matches the website's `post:created` window event +
                // prepend behavior).
                val newFeedItem = FeedItemDto(kind = "post", post = newPost)
                val current = _state.value
                _state.value = current.copy(
                    items = listOf(newFeedItem) + current.items,
                )
                _events.tryEmit("Post published.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _events.tryEmit(e.message ?: "Could not publish post.")
            }
        }
    }
}

