package com.centrychat.android.feature.feed

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.data.repository.AuthRepository
import com.centrychat.android.ui.components.CentryChatAvatar

/**
 * Phase 4 parity — Inline "What's Happening?" composer on the home feed.
 *
 * Mirrors the website's `HomeComposer` at
 * `src/components/posts/home-composer.tsx`:
 *
 *   - Collapsed state: a row with the current user's avatar + the
 *     "What's happening?" prompt + a small "New post" pill button (with
 *     the Edit/PenSquare icon). Tapping anywhere on the row expands it.
 *
 *   - Expanded state: avatar + a 3-row textarea (no inner border —
 *     matches the website's `border-0 px-0 shadow-none focus-visible:ring-0`
 *     styling) + a top-border with the char counter + Post button on the
 *     right.
 *
 *   - On submit success: clears the text + collapses back to the prompt
 *     (caller — FeedViewModel.createPost — prepends the new post to the
 *     feed + emits a snackbar). Mirrors the website's
 *     `post:created` window-event + prepend + blur-to-collapse flow.
 *
 *   - On submit failure: keeps the text (so the user can retry), stays
 *     expanded, + emits a snackbar via [onError] / [onSuccess] callbacks.
 *
 * Phase 4 change: this REPLACES the previous ExtendedFloatingActionButton
 * that was at the bottom-right of the feed. The FAB was a duplicate
 * entry point — the website has only the inline composer + a top-nav
 * "New post" button (which we don't render because Android's top app
 * bar is intentionally minimal). The inline composer is the canonical
 * entry point + matches the website exactly.
 *
 * Phase 1 (text-only) — matches the website's HomeComposer scope:
 *   - No camera, no microphone, no photo attachment. The website's
 *     HomeComposer is text-only by design (the camera/microphone UI was
 *     removed in the website's Phase 1 UI change — see the comment at
 *     `src/components/posts/home-composer.tsx:22-33`). Posts ARE text-only
 *     at the backend level (no PostMedia model exists).
 *
 * @param onSubmit called with the trimmed content when the user taps Post.
 *   The caller (FeedViewModel.createPost) handles the API call + the
 *   success/error snackbar.
 */
@Composable
fun HomeComposer(
    onSubmit: (String) -> Unit,
) {
    val appContainer = LocalAppContainer.current
    val authRepo: AuthRepository = appContainer.authRepository
    val currentUser by authRepo.currentUser.collectAsStateWithLifecycle()

    // Use rememberSaveable so the text survives config changes (rotation)
    // + is restored if the composer collapses + re-expands.
    var content by rememberSaveable { mutableStateOf("") }
    var expanded by rememberSaveable { mutableStateOf(false) }
    var submitting by remember { mutableStateOf(false) }

    // Focus requester so the textarea is auto-focused when expanded
    // (matches the website's `textareaRef.current?.focus()`).
    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(expanded) {
        if (expanded) {
            // Small delay so the composition is committed before focus.
            kotlinx.coroutines.delay(30)
            try { focusRequester.requestFocus() } catch (_: Exception) {}
        }
    }

    // POST_MAX_LENGTH is 280 code points — matches the website's parser.ts.
    val charCount = content.codePointCount(0, content.length)
    val overLimit = charCount > 280
    val isEmpty = content.isBlank()
    val canSubmit = !isEmpty && !overLimit && !submitting

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
    ) {
        if (!expanded) {
            // ── Collapsed state — matches website's home-composer.tsx:120-141 ─
            // A full-width clickable row: avatar + "What's happening?" prompt
            // + a small "New post" pill (with Edit icon) on the right.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = true }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                CentryChatAvatar(
                    fullName = currentUser?.fullName ?: "?",
                    avatarColor = currentUser?.avatarColor,
                    avatarUrl = currentUser?.avatarUrl,
                    onClick = { /* Don't expand on avatar tap — let the user navigate to profile */ },
                    size = 32.dp,
                )
                Text(
                    text = stringResource(R.string.feed_composer_placeholder),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                // "New post" pill button — mirrors the website's
                // `hidden shrink-0 items-center gap-1 rounded-md bg-primary
                //  px-3 py-1.5 text-xs font-medium` (sm:flex = visible on
                // phone widths too on Android, since we don't have the
                // desktop-specific hidden constraint).
                Surface(
                    color = MaterialTheme.colorScheme.primary,
                    shape = RoundedCornerShape(6.dp),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp),
                        )
                        Text(
                            text = stringResource(R.string.feed_composer_new_post),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }
            }
        } else {
            // ── Expanded state — matches website's home-composer.tsx:144-180 ─
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    CentryChatAvatar(
                        fullName = currentUser?.fullName ?: "?",
                        avatarColor = currentUser?.avatarColor,
                        avatarUrl = currentUser?.avatarUrl,
                        onClick = {},
                        size = 32.dp,
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = content,
                            onValueChange = { content = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(focusRequester),
                            placeholder = { Text(stringResource(R.string.feed_composer_placeholder)) },
                            // Matches the website's `border-0 px-0 shadow-none
                            // focus-visible:ring-0` — we use a transparent
                            // container + no outline to mimic that.
                            singleLine = false,
                            maxLines = 4,
                            enabled = !submitting,
                            shape = RoundedCornerShape(0.dp),
                        )
                        // Char counter + Post button row (matches the
                        // website's `flex items-center justify-between
                        // gap-2 border-t pt-2`).
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            // Char counter — only visible when close to the limit
                            // (matches the website's behavior: shows from 240 onward).
                            if (charCount > 240) {
                                Text(
                                    text = "$charCount / 280",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (overLimit)
                                        MaterialTheme.colorScheme.error
                                    else
                                        MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            } else {
                                Spacer(Modifier.size(0.dp))
                            }
                            // Post button.
                            androidx.compose.material3.Button(
                                onClick = {
                                    if (canSubmit) {
                                        submitting = true
                                        onSubmit(content.trim())
                                        // Optimistic collapse — the FeedViewModel
                                        // surfaces errors via the events flow
                                        // (snackbar). On failure the user can
                                        // re-expand + retry.
                                        // NOTE: we DON'T clear content here —
                                        // the FeedViewModel.createPost on
                                        // success will trigger a snackbar,
                                        // and we clear content + collapse
                                        // after a short delay so the user
                                        // sees the post appear at the top of
                                        // the feed before the composer resets.
                                    }
                                },
                                enabled = canSubmit,
                            ) {
                                if (submitting) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(14.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                    )
                                } else {
                                    Text(stringResource(R.string.feed_composer_post_button))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
