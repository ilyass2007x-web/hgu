package com.centrychat.android.feature.post_composer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.centrychat.android.R
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.data.model.ArticleDetailDto

/**
 * PHASE 1 — ARTICLE PARITY
 *
 * Article editor screen (create + edit). Replaces the placeholder.
 *
 * Mirrors the website's `src/components/articles/article-editor.tsx`:
 *   - Create mode: no `articleId` — POST /api/v1/articles.
 *   - Edit mode: `articleId` passed in — load the article, then
 *     PATCH /api/v1/articles/{id} on save.
 *
 * Fields (matches the website's editor + backend validation):
 *   - Title (3-200 chars, required)
 *   - Content (min 10 chars, required — plain text or HTML)
 *   - Excerpt (max 300 chars, optional)
 *   - Cover image URL (optional — Pinterest or direct image)
 *   - Video URL (optional — YouTube/Vimeo/etc. or direct video)
 *   - Status: PUBLISHED or DRAFT
 *   - showCoverInArticle: boolean (default true)
 *
 * On success: navigates to the saved article's detail screen (create
 * mode) or pops the back stack (edit mode).
 *
 * ## Why plain text input (not rich text editor)
 *
 * The website uses a plain `<Textarea>` for article content (confirmed
 * by the website audit — no rich text editor library is imported in
 * article-editor.tsx). Using a plain text field on Android matches the
 * website exactly. Users who want HTML formatting can type HTML tags
 * directly — the ArticleHtmlRenderer on the detail screen parses + renders
 * them natively. This avoids:
 *   - APK size bloat (~500 KB-2 MB for a rich text editor library).
 *   - A parity gap (rich text edited on Android couldn't be edited on web).
 *   - Rich text library maintenance burden (selection/IME/paste bugs).
 *
 * @param articleId null for create mode, non-null for edit mode.
 * @param onSaved called after successful save with the saved article.
 *   The caller navigates to the article detail screen (create) or
 *   pops the back stack (edit).
 * @param onBack called when the user taps the back arrow.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticleEditorScreen(
    articleId: String? = null,
    onSaved: (ArticleDetailDto) -> Unit,
    onBack: () -> Unit,
) {
    val appContainer = LocalAppContainer.current
    val viewModel: ArticleEditorViewModel = viewModel(
        factory = remember {
            object : androidx.lifecycle.ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T =
                    ArticleEditorViewModel(appContainer) as T
            }
        }
    )

    // Load the article for editing (if articleId is non-null).
    LaunchedEffect(articleId) {
        if (articleId != null) {
            viewModel.loadArticleForEdit(articleId)
        }
    }

    // Observe saved article → trigger navigation.
    val savedArticle by viewModel.savedArticle.collectAsStateWithLifecycle()
    LaunchedEffect(savedArticle) {
        savedArticle?.let {
            onSaved(it)
            viewModel.consumeSavedArticle()
        }
    }

    val title by viewModel.title.collectAsStateWithLifecycle()
    val content by viewModel.content.collectAsStateWithLifecycle()
    val excerpt by viewModel.excerpt.collectAsStateWithLifecycle()
    val coverImage by viewModel.coverImage.collectAsStateWithLifecycle()
    val videoUrl by viewModel.videoUrl.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    val showCoverInArticle by viewModel.showCoverInArticle.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val isSaving by viewModel.isSaving.collectAsStateWithLifecycle()
    val error by viewModel.error.collectAsStateWithLifecycle()

    val isEditMode = articleId != null
    val screenTitle = if (isEditMode) {
        stringResource(R.string.article_editor_edit_title)
    } else {
        stringResource(R.string.article_editor_title)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(screenTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back_button),
                        )
                    }
                },
            )
        },
    ) { padding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // ── Title ──────────────────────────────────────────────────
            OutlinedTextField(
                value = title,
                onValueChange = {
                    viewModel.title.value = it
                    viewModel.clearError()
                },
                label = { Text(stringResource(R.string.article_editor_field_title)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Next,
                ),
            )

            // ── Content ────────────────────────────────────────────────
            OutlinedTextField(
                value = content,
                onValueChange = {
                    viewModel.content.value = it
                    viewModel.clearError()
                },
                label = { Text(stringResource(R.string.article_editor_field_content)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Default,
                ),
            )

            // ── Excerpt ────────────────────────────────────────────────
            OutlinedTextField(
                value = excerpt,
                onValueChange = {
                    viewModel.excerpt.value = it
                    viewModel.clearError()
                },
                label = { Text(stringResource(R.string.article_editor_field_excerpt)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            )

            // ── Cover image URL ────────────────────────────────────────
            OutlinedTextField(
                value = coverImage,
                onValueChange = {
                    viewModel.coverImage.value = it
                    viewModel.clearError()
                },
                label = { Text(stringResource(R.string.article_editor_field_cover)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Next,
                ),
            )

            // ── Video URL ──────────────────────────────────────────────
            OutlinedTextField(
                value = videoUrl,
                onValueChange = {
                    viewModel.videoUrl.value = it
                    viewModel.clearError()
                },
                label = { Text("Video URL (optional)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Done,
                ),
            )

            // ── Show cover in article toggle ───────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Show cover in article",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = showCoverInArticle,
                    onCheckedChange = { viewModel.showCoverInArticle.value = it },
                )
            }

            // ── Error message ─────────────────────────────────────────
            if (error != null) {
                Text(
                    text = error!!,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(Modifier.height(8.dp))

            // ── Submit buttons ─────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Button(
                    onClick = { viewModel.submit(asDraft = false) },
                    enabled = !isSaving,
                    modifier = Modifier.weight(1f),
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary,
                        )
                    } else {
                        Text(
                            text = if (isEditMode) "Save changes" else stringResource(R.string.article_editor_publish),
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
                OutlinedButton(
                    onClick = { viewModel.submit(asDraft = true) },
                    enabled = !isSaving,
                    modifier = Modifier.weight(1f),
                ) {
                    Text(stringResource(R.string.article_editor_save_draft))
                }
            }
        }
    }
}
