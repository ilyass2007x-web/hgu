package com.centrychat.android.navigation

import android.net.Uri

/**
 * Phase 3 — Deep-link URL parser.
 *
 * Pure functions (no Android framework dependencies — `Uri` is only used
 * at the call site in [com.centrychat.android.MainActivity]; the actual
 * parsing works on plain Strings so it's unit-testable without
 * Robolectric / MockK).
 *
 * URL formats accepted (mirrors the AndroidManifest.xml intent-filters):
 *   - https://sentrychat.netlify.app/?post={postId}     → Post(postId)
 *   - https://sentrychat.netlify.app/articles/{id}      → Article(id)
 *   - centrychat://post/{id}                             → Post(postId)
 *   - centrychat://article/{id}                          → Article(id)
 *
 * Anything else → null (no navigation — the user lands on the feed).
 *
 * Safety:
 *   - Invalid / malformed URLs → null (no crash, no black screen)
 *   - Empty post/article IDs → null
 *   - Non-sentrychat hosts → null (deep-link only matches the live deployment)
 *   - http:// (not https://) → null (we only auto-verify https)
 */
object DeepLinkParser {

    /**
     * Parse a [Uri] into a [DeepLinkTarget] or null.
     *
     * Forwards to [parseString] after converting the Uri to its string
     * representation. The conversion is the only Android-framework call —
     * the actual parsing logic lives in [parseString] which is pure
     * Kotlin + unit-tested.
     */
    fun parse(uri: Uri?): DeepLinkTarget? {
        if (uri == null) return null
        return parseString(uri.toString())
    }

    /**
     * Pure-Kotlin parser. Maps a URL string into a [DeepLinkTarget] or null.
     *
     * Accepted formats (see class doc).
     *
     * @param url the full URL string (e.g. "https://sentrychat.netlify.app/articles/abc123")
     * @return the matching [DeepLinkTarget], or null if the URL doesn't match any known format.
     */
    fun parseString(url: String): DeepLinkTarget? {
        if (url.isBlank()) return null

        // Determine the scheme by finding "://".
        val schemeEnd = url.indexOf("://")
        if (schemeEnd <= 0) return null
        val scheme = url.substring(0, schemeEnd).lowercase()
        val rest = url.substring(schemeEnd + 3) // everything after "://"

        return when (scheme) {
            "https" -> parseHttps(rest)
            "centrychat" -> parseCustomScheme(rest)
            else -> null
        }
    }

    /**
     * Parse the part after "https://" — expected format: `host/path?query`.
     *
     * Examples accepted:
     *   sentrychat.netlify.app/?post=abc123
     *   sentrychat.netlify.app/articles/abc123
     *   sentrychat.netlify.app/articles/abc123/
     *   sentrychat.netlify.app/?post=abc123&ref=whatsapp
     */
    private fun parseHttps(rest: String): DeepLinkTarget? {
        // Split host/path?query at the first '/'.
        val slashIdx = rest.indexOf('/')
        val host: String
        val pathAndQuery: String
        if (slashIdx < 0) {
            host = rest
            pathAndQuery = ""
        } else {
            host = rest.substring(0, slashIdx)
            pathAndQuery = rest.substring(slashIdx + 1) // drop the leading '/'
        }
        // Lowercase the host for case-insensitive comparison.
        if (host.lowercase() != "sentrychat.netlify.app") return null

        // Split path and query at '?'.
        val qIdx = pathAndQuery.indexOf('?')
        val path = if (qIdx < 0) pathAndQuery else pathAndQuery.substring(0, qIdx)
        val query = if (qIdx < 0) "" else pathAndQuery.substring(qIdx + 1)

        val normalizedPath = if (path.isEmpty()) "/" else "/$path"

        return when {
            // /articles/{articleId}
            normalizedPath.startsWith("/articles/") -> {
                val articleId = normalizedPath.removePrefix("/articles/").trimEnd('/')
                if (articleId.isNotBlank()) DeepLinkTarget.Article(articleId) else null
            }
            // /?post={postId}
            normalizedPath == "/" -> {
                val postId = extractQueryParam(query, "post")
                if (!postId.isNullOrBlank()) DeepLinkTarget.Post(postId) else null
            }
            else -> null
        }
    }

    /**
     * Parse the part after "centrychat://" — expected format: `host/path`.
     *
     * Examples accepted:
     *   post/abc123
     *   article/article456
     */
    private fun parseCustomScheme(rest: String): DeepLinkTarget? {
        // Split at first '/'.
        val slashIdx = rest.indexOf('/')
        val host: String
        val path: String
        if (slashIdx < 0) {
            host = rest
            path = ""
        } else {
            host = rest.substring(0, slashIdx)
            path = rest.substring(slashIdx + 1)
        }

        val cleanHost = host.lowercase()
        val cleanPath = path.trimEnd('/').trim()

        return when (cleanHost) {
            "post" -> if (cleanPath.isNotBlank()) DeepLinkTarget.Post(cleanPath) else null
            "article" -> if (cleanPath.isNotBlank()) DeepLinkTarget.Article(cleanPath) else null
            else -> null
        }
    }

    /**
     * Tiny query-string parser. Extracts the value for the given key
     * from a `key1=value1&key2=value2` style string. Returns null if
     * the key is not present.
     */
    private fun extractQueryParam(query: String, key: String): String? {
        if (query.isBlank()) return null
        for (pair in query.split('&')) {
            val eqIdx = pair.indexOf('=')
            val k = if (eqIdx < 0) pair else pair.substring(0, eqIdx)
            val v = if (eqIdx < 0) "" else pair.substring(eqIdx + 1)
            if (k == key) return v
        }
        return null
    }
}
