package com.centrychat.android.feature.post_detail

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.centrychat.android.R
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.core.util.TimeFormatter
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.RelatedArticleDto
import com.centrychat.android.ui.components.CentryChatAvatar
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState
import com.centrychat.android.ui.components.VerifiedBadge

/**
 * PHASE 1 — ARTICLE PARITY
 *
 * Article detail screen. Renders article content with the native HTML
 * renderer (ArticleHtmlRenderer), supports like/comment/share/delete/
 * translate/insights/related articles, and records a view on mount.
 *
 * Mirrors the website's `src/components/articles/article-reading-page.tsx`:
 *   - Header: cover image OR video (via UnifiedVideoPlayer) + title +
 *     author + verification badge + published date + reading time.
 *   - Body: ArticleHtmlRenderer (parses + sanitizes HTML, renders as
 *     native Compose UI — no WebView, no JavaScript execution).
 *   - Actions: Like / Comment / Share (server-authoritative counts).
 *   - Owner actions: Edit / Delete / Insights (BarChart icon).
 *   - Translation: language selector → loads translated content (PUBLIC,
 *     GLM-4.6 via z-ai-web-dev-sdk).
 *   - Related articles: fetched on mount (PUBLIC, scoring algorithm).
 *   - View tracking: fires once per mount (PUBLIC, cc_visitor equivalent).
 *
 * @param articleId the article ID to display.
 * @param onBack called when the user taps the back arrow.
 * @param onUserClick called with a username when the user taps an avatar/name.
 * @param onEdit called when the owner taps the Edit button (navigates to
 *   the article editor in edit mode).
 * @param onInsights called when the owner taps the Insights button.
 * @param onDeleted called after the article is deleted (navigates back).
 * @param onRelatedArticleClick called when the user taps a related article.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticleDetailScreen(
    articleId: String,
    onBack: () -> Unit,
    onUserClick: (String) -> Unit,
    onEdit: (String) -> Unit = {},
    onInsights: (String) -> Unit = {},
    onDeleted: () -> Unit = {},
    onRelatedArticleClick: (String) -> Unit = {},
) {
    val appContainer = LocalAppContainer.current
    val viewModel: ArticleDetailViewModel = viewModel(
        factory = remember {
            object : androidx.lifecycle.ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T =
                    ArticleDetailViewModel(appContainer) as T
            }
        }
    )
    val state by viewModel.state.collectAsStateWithLifecycle()
    val commentsState by viewModel.commentsState.collectAsStateWithLifecycle()
    val isSending by viewModel.isSendingComment.collectAsStateWithLifecycle()
    val replyTarget by viewModel.replyTarget.collectAsStateWithLifecycle()
    val relatedState by viewModel.relatedState.collectAsStateWithLifecycle()
    val translation by viewModel.translation.collectAsStateWithLifecycle()
    val isTranslating by viewModel.isTranslating.collectAsStateWithLifecycle()
    val translationError by viewModel.translationError.collectAsStateWithLifecycle()
    val deleted by viewModel.deleted.collectAsStateWithLifecycle()
    val currentUser by appContainer.authRepository.currentUser.collectAsState()
    val context = LocalContext.current
    // Phase 3 — snackbar host for transient comment-delete failures.
    val snackbarHostState = remember { androidx.compose.material3.SnackbarHostState() }

    // ── Load article + comments + related + record view on mount ──
    LaunchedEffect(articleId) {
        viewModel.loadArticle(articleId)
        viewModel.loadComments(articleId)
    }
    // Record view once the article is loaded (separate LaunchedEffect
    // so it fires after the article is available — the ViewModel checks
    // `_viewRecorded.value` to ensure it fires only once per instance).
    LaunchedEffect(state) {
        if (state is UiState.Success) {
            viewModel.recordView(articleId)
            viewModel.loadRelatedArticles(articleId)
        }
    }
    // Navigate away after delete.
    LaunchedEffect(deleted) {
        if (deleted) onDeleted()
    }
    // Phase 3 — collect transient UI events from the ViewModel → snackbar.
    LaunchedEffect(viewModel) {
        viewModel.events.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    var commentText by remember { mutableStateOf("") }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showLanguageMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.articles_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back_button),
                        )
                    }
                },
                actions = {
                    // Owner actions: Edit, Insights, Delete (only shown when canManage).
                    val article = (state as? UiState.Success)?.data
                    if (article != null && currentUser != null) {
                        val isOwner = article.author.id == currentUser!!.id ||
                            article.author.username == currentUser!!.username
                        val isAdmin = currentUser!!.role == "ADMIN" || currentUser!!.role == "SUPER_ADMIN"
                        if (isOwner || isAdmin) {
                            IconButton(onClick = { onInsights(articleId) }) {
                                Icon(
                                    imageVector = Icons.Filled.BarChart,
                                    contentDescription = "Insights",
                                )
                            }
                            IconButton(onClick = { onEdit(articleId) }) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "Edit article",
                                )
                            }
                            IconButton(onClick = { showDeleteDialog = true }) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Delete article",
                                    tint = MaterialTheme.colorScheme.error,
                                )
                            }
                        }
                    }
                    // Translation menu (always available — endpoint is PUBLIC).
                    IconButton(onClick = { showLanguageMenu = true }) {
                        Icon(
                            imageVector = Icons.Filled.Language,
                            contentDescription = "Translate",
                        )
                    }
                    TranslationLanguageMenu(
                        expanded = showLanguageMenu,
                        onDismiss = { showLanguageMenu = false },
                        onLanguageSelected = { code ->
                            showLanguageMenu = false
                            if (code == "original") {
                                viewModel.clearTranslation()
                            } else {
                                viewModel.translateArticle(articleId, code)
                            }
                        },
                    )
                },
            )
        },
        // Phase 3 — snackbar host for comment-delete failures.
        snackbarHost = { androidx.compose.material3.SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            ArticleCommentInputBar(
                text = commentText,
                onTextChange = { commentText = it },
                isSending = isSending,
                replyTarget = replyTarget,
                onSend = {
                    viewModel.sendComment(
                        articleId = articleId,
                        content = commentText,
                        parentCommentId = replyTarget?.id,
                    )
                    commentText = ""
                },
                onCancelReply = { viewModel.setReplyTarget(null) },
            )
        },
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)) {
            when (val s = state) {
                UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                is UiState.Error -> ErrorState(message = s.message, onRetry = { viewModel.loadArticle(articleId) })
                UiState.Empty -> EmptyState(message = "Article not found.")
                is UiState.Success -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        item {
                            ArticleHeader(
                                article = s.data,
                                onUserClick = onUserClick,
                                onLike = { viewModel.toggleLike(articleId) },
                                onShare = {
                                    // Phase 3 — Share now includes the CANONICAL CentryChat URL.
                                    // Website article share URL = `${origin}/articles/${articleId}`.
                                    // We mirror that exactly so the URL opens the app via deep-link
                                    // when the receiver has CentryChat installed, and falls back to
                                    // the website on those who don't.
                                    val shareUrl = "${com.centrychat.android.BuildConfig.API_BASE_URL}/articles/${s.data.id}"
                                    val shareText = "${s.data.title} — by @${s.data.author.username} on CentryChat\n\n$shareUrl"
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, s.data.title)
                                        putExtra(Intent.EXTRA_TEXT, shareText)
                                    }
                                    // Native Android share sheet — receiver chooses WhatsApp /
                                    // Facebook / Messenger / Telegram / Gmail / Copy Link / any
                                    // installed app. NOT hard-coded to any specific package.
                                    val chooser = Intent.createChooser(shareIntent, "Share article")
                                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    try {
                                        context.startActivity(chooser)
                                        viewModel.shareArticle(articleId)
                                    } catch (_: Exception) {
                                        // No app to handle — silent
                                    }
                                },
                                translation = translation,
                                isTranslating = isTranslating,
                                translationError = translationError,
                                onInternalRoute = { /* TODO: wire to NavController — for now, links open externally */ },
                            )
                        }
                        // ── Phase 3: Section order matches user requirement ─────
                        // Article content → Comments → Related Articles.
                        // (Previously was content → related → comments, which
                        // interrupted the article body with related cards
                        // before the comments section. User explicitly asked
                        // for content → comments → related in §2 of the spec.)
                        item {
                            Text(
                                text = stringResource(R.string.comments_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            )
                        }
                        when (val cState = commentsState) {
                            UiState.Loading -> item {
                                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            }
                            is UiState.Error -> item {
                                ErrorState(message = cState.message, onRetry = { viewModel.loadComments(articleId) })
                            }
                            UiState.Empty -> item {
                                EmptyState(message = stringResource(R.string.comments_empty))
                            }
                            is UiState.Success -> {
                                items(cState.data) { comment ->
                                    ArticleCommentRow(
                                        comment = comment,
                                        onUserClick = onUserClick,
                                        onLike = { viewModel.toggleCommentLike(comment.id) },
                                        onReply = { viewModel.setReplyTarget(comment) },
                                        canDelete = viewModel.canDeleteComment(comment),
                                        onDelete = { viewModel.deleteComment(articleId, comment) },
                                    )
                                }
                            }
                        }
                        // ── Related Articles — rendered AFTER Comments ───────
                        // Mirrors the website's article detail page order:
                        //   <ArticleReadingPage> (content) → <RelatedArticles>
                        // On Android, comments live inline (the website puts
                        // them on a separate route), so the user's requested
                        // order is content → comments → related. Related
                        // articles remain clickable + open the article detail.
                        when (val r = relatedState) {
                            UiState.Loading -> { /* no-op — don't show a spinner here */ }
                            is UiState.Error -> { /* no-op — related articles failure is silent */ }
                            UiState.Empty -> { /* no-op — no related articles */ }
                            is UiState.Success -> {
                                if (r.data.isNotEmpty()) {
                                    item {
                                        RelatedArticlesSection(
                                            articles = r.data,
                                            onArticleClick = onRelatedArticleClick,
                                            onUserClick = onUserClick,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete confirmation dialog.
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete this article?") },
            text = {
                Text("This article will be permanently deleted. This action cannot be undone. All likes, comments, and views will be removed.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        viewModel.deleteArticle(articleId)
                    },
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel")
                }
            },
        )
    }
}

@Composable
private fun ArticleHeader(
    article: ArticleDetailDto,
    onUserClick: (String) -> Unit,
    onLike: () -> Unit,
    onShare: () -> Unit,
    translation: com.centrychat.android.data.model.ArticleTranslationDto?,
    isTranslating: Boolean,
    translationError: String?,
    onInternalRoute: (String) -> Unit,
) {
    Column(Modifier.padding(16.dp)) {
        // ── Media block: video OR cover image, mirroring the website's
        // Article reading page (see src/components/articles/article-reading-page.tsx
        // + src/components/media/media-renderer.tsx).
        if (article.showCoverInArticle) {
            val hasVideo = !article.videoUrl.isNullOrBlank()
            val hasImage = !article.coverImage.isNullOrBlank()
            when {
                hasVideo -> {
                    com.centrychat.android.ui.components.UnifiedVideoPlayer(
                        rawUrl = article.videoUrl,
                        posterUrl = article.coverImage,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(12.dp))
                }
                hasImage -> {
                    AsyncImage(
                        model = article.coverImage,
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier.fillMaxWidth().height(220.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                }
            }
        }

        // ── Title (translated if a translation is active) ──────────────
        val displayTitle = translation?.translatedTitle ?: article.title
        Text(
            text = displayTitle,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            CentryChatAvatar(
                fullName = article.author.fullName,
                avatarColor = article.author.avatarColor,
                avatarUrl = article.author.avatarUrl,
                onClick = { onUserClick(article.author.username) },
                size = 36.dp,
            )
            Spacer(Modifier.size(8.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = article.author.fullName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (article.author.isVerified) {
                        Spacer(Modifier.size(4.dp))
                        VerifiedBadge()
                    }
                }
                Text(
                    text = "@${article.author.username} · ${TimeFormatter.dateTime(article.publishedAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (article.readingTime != null && article.readingTime > 0) {
                Text(
                    text = stringResource(R.string.articles_reading_time, article.readingTime),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Translation indicator ─────────────────────────────────────
        if (translation != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Filled.Language,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.primary,
                )
                Spacer(Modifier.size(6.dp))
                Text(
                    text = "Translated to ${translation.languageNativeName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        if (isTranslating) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(14.dp),
                    strokeWidth = 2.dp,
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = "Translating…",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (translationError != null) {
            Text(
                text = translationError,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }

        // ── Content: HTML renderer (Phase 1 P0 fix) ───────────────────
        // Replaces the previous `Text(article.content)` that displayed raw
        // HTML tags as plain text. Now parses + sanitizes HTML with Jsoup
        // + renders as native Compose UI (no WebView, no JS execution).
        val displayContent = translation?.translatedContent ?: article.content
        ArticleHtmlRenderer(
            content = displayContent,
            modifier = Modifier.fillMaxWidth(),
            onInternalRoute = onInternalRoute,
        )

        Spacer(Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            ArticleEngagementButton(
                icon = if (article.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                count = article.likeCount,
                active = article.isLiked,
                onClick = onLike,
            )
            ArticleEngagementButton(
                icon = Icons.Filled.ChatBubbleOutline,
                count = article.commentCount,
            )
            ArticleEngagementButton(
                icon = Icons.Filled.Share,
                count = article.shareCount,
                onClick = onShare,
            )
        }
    }
}

@Composable
private fun ArticleEngagementButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Long,
    active: Boolean = false,
    onClick: () -> Unit = {},
) {
    IconButton(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.size(4.dp))
            Text(
                text = TextUtils.compactCount(count),
                style = MaterialTheme.typography.bodySmall,
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ArticleCommentRow(
    comment: CommentDto,
    onUserClick: (String) -> Unit,
    onLike: () -> Unit,
    onReply: () -> Unit,
    canDelete: Boolean = false,
    onDelete: () -> Unit = {},
) {
    // Phase 3 — delete confirmation dialog state. Mirrors the website's
    // AlertDialog in the article CommentThread component.
    var showDeleteDialog by remember { mutableStateOf(false) }

    Column(Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CentryChatAvatar(
                fullName = comment.author.fullName,
                avatarColor = comment.author.avatarColor,
                avatarUrl = comment.author.avatarUrl,
                onClick = { onUserClick(comment.author.username) },
                size = 32.dp,
            )
            Spacer(Modifier.size(8.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = comment.author.fullName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (comment.author.isVerified) {
                        Spacer(Modifier.size(4.dp))
                        VerifiedBadge()
                    }
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "· ${TimeFormatter.relative(comment.createdAt)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = comment.content,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(start = 40.dp),
        )
        Spacer(Modifier.height(4.dp))
        // ── Phase 3: Comment action row — mirrors website comment-thread.tsx ─
        // Heart (14dp, red when liked) + Reply (CornerDownRight + label) +
        // Trash (12dp, only when canDelete). Matches the website exactly.
        Row(
            modifier = Modifier.padding(start = 40.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            // Like (Heart)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onLike)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = if (comment.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = if (comment.isLiked) "Unlike" else "Like",
                    tint = if (comment.isLiked) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp),
                )
                if (comment.likeCount > 0) {
                    Spacer(Modifier.size(4.dp))
                    Text(
                        text = TextUtils.compactCount(comment.likeCount),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (comment.isLiked) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            // Reply
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onReply)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Filled.Reply,
                    contentDescription = "Reply",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp),
                )
                Spacer(Modifier.size(4.dp))
                Text(
                    text = "Reply",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            // Delete (Trash) — only when canDelete
            if (canDelete) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showDeleteDialog = true }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = "Delete comment",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(12.dp),
                    )
                }
            }
        }
        if (comment.replies.isNotEmpty()) {
            Column(modifier = Modifier
                .padding(start = 40.dp, top = 8.dp)) {
                comment.replies.forEach { reply ->
                    ArticleCommentRow(
                        comment = reply,
                        onUserClick = onUserClick,
                        onLike = onLike,
                        onReply = onReply,
                        canDelete = canDelete,
                        onDelete = onDelete,
                    )
                }
            }
        }
    }

    // Delete confirmation dialog.
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(stringResource(R.string.post_delete_dialog_title)) },
            text = { Text(stringResource(R.string.post_delete_dialog_message)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        onDelete()
                    }
                ) {
                    Text(
                        stringResource(R.string.post_delete_confirm),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(stringResource(R.string.post_delete_cancel))
                }
            },
        )
    }
}

@Composable
private fun ArticleTextButton(text: String, count: Long?, onClick: () -> Unit, active: Boolean = false) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = if (count != null) "$text · ${TextUtils.compactCount(count)}" else text,
            style = MaterialTheme.typography.labelMedium,
            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ArticleCommentInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    isSending: Boolean,
    replyTarget: CommentDto?,
    onSend: () -> Unit,
    onCancelReply: () -> Unit,
) {
    Column(Modifier
        .fillMaxWidth()
        .padding(8.dp)) {
        if (replyTarget != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.comments_reply_to, "@${replyTarget.author.username}"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onCancelReply) {
                    Icon(Icons.Filled.Close, contentDescription = "Cancel reply")
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.comments_input_placeholder)) },
                singleLine = false,
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                shape = RoundedCornerShape(24.dp),
            )
            Spacer(Modifier.size(8.dp))
            IconButton(
                onClick = onSend,
                enabled = text.isNotBlank() && !isSending,
            ) {
                if (isSending) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.cd_send_comment),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
    }
}

// ── Related articles section ─────────────────────────────────────────────

@Composable
private fun RelatedArticlesSection(
    articles: List<RelatedArticleDto>,
    onArticleClick: (String) -> Unit,
    onUserClick: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Filled.MoreVert,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.size(8.dp))
            Text(
                text = "Related articles",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Spacer(Modifier.height(8.dp))
        articles.forEach { related ->
            RelatedArticleRow(
                article = related,
                onArticleClick = onArticleClick,
                onUserClick = onUserClick,
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun RelatedArticleRow(
    article: RelatedArticleDto,
    onArticleClick: (String) -> Unit,
    onUserClick: (String) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onArticleClick(article.id) }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Thumbnail (if cover image).
        if (!article.coverImage.isNullOrBlank()) {
            AsyncImage(
                model = article.coverImage,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(6.dp)),
            )
            Spacer(Modifier.size(12.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = article.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
            )
            if (!article.excerpt.isNullOrBlank()) {
                Text(
                    text = article.excerpt,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                )
            }
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CentryChatAvatar(
                    fullName = article.author.fullName,
                    avatarColor = article.author.avatarColor,
                    avatarUrl = article.author.avatarUrl,
                    onClick = { onUserClick(article.author.username) },
                    size = 16.dp,
                )
                Spacer(Modifier.size(4.dp))
                Text(
                    text = article.author.fullName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (article.author.isVerified) {
                    Spacer(Modifier.size(2.dp))
                    VerifiedBadge()
                }
                if (!article.reason.isNullOrBlank()) {
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "· ${article.reason}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
    }
}
