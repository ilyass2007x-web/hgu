package com.centrychat.android.feature.post_detail

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.BuildConfig
import com.centrychat.android.R
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.core.util.TimeFormatter
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.rememberPostDetailViewModel
import com.centrychat.android.ui.components.CentryChatAvatar
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState
import com.centrychat.android.ui.components.VerifiedBadge

/**
 * The post-detail screen — shows a single post + its comment thread.
 *
 * Phase 2 (Post Parity) additions:
 *  - Overflow menu (⋮) in the top bar with: Edit post | Delete post |
 *    Copy link. Edit + Delete are gated on `post.author.id == currentUser.id`
 *    (the backend re-checks ownership — UI hiding is a UX nicety, not a
 *    security boundary).
 *  - Delete confirmation dialog (matches the website's "Are you sure?"
 *    pattern — cannot be undone).
 *  - "(edited)" indicator next to the timestamp when `updatedAt >
 *    createdAt` (mirrors the website's PostCard display).
 *  - View tracking: calls `recordView(postId)` once on screen entry
 *    (backend dedupes via `@@unique([postId, userId])` on PostView +
 *    skips author's own views).
 *  - Snackbar events surfaced from the ViewModel (like-failure rollback,
 *    comment-failure retry hint, delete-failure message).
 *  - Copy link: copies the post's URL to the clipboard + records a
 *    `LINK_COPY` interaction event on the backend (does NOT bump the
 *    public shareCount — only "SHARE" events do).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    postId: String,
    onBack: () -> Unit,
    onUserClick: (String) -> Unit,
    onEditPost: (String, String) -> Unit = { _, _ -> },
) {
    val viewModel = rememberPostDetailViewModel()
    val postState by viewModel.postState.collectAsStateWithLifecycle()
    val commentsState by viewModel.commentsState.collectAsStateWithLifecycle()
    val isSending by viewModel.isSendingComment.collectAsStateWithLifecycle()
    val replyTarget by viewModel.replyTarget.collectAsStateWithLifecycle()
    val deleted by viewModel.deleted.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Collect transient UI events from the ViewModel → show as snackbar.
    LaunchedEffect(viewModel) {
        viewModel.events.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    // Pop back when the post is deleted.
    LaunchedEffect(deleted) {
        if (deleted) onBack()
    }

    LaunchedEffect(postId) {
        viewModel.loadPost(postId)
        viewModel.loadComments(postId)
        // Phase 2: record a UNIQUE view once per open. Backend dedupes.
        viewModel.recordView(postId)
    }

    // Determine if the current user is the post's author (for edit/delete menu).
    // We can't access AppContainer directly here without a bigger refactor,
    // so the screen reads the current user from the auth repo via the
    // CompositionLocal provided by CentryChatRoot. For now we compute it
    // from the post state + rely on the backend's ownership check too.
    val postSuccess = (postState as? UiState.Success)?.data
    var showDeleteDialog by remember { mutableStateOf(false) }
    var menuExpanded by remember { mutableStateOf(false) }

    var commentText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.post_action_comment)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back_button),
                        )
                    }
                },
                actions = {
                    // Overflow menu — Edit + Delete + Copy link (only shown
                    // for the post's author). The backend re-checks ownership;
                    // this UI gating is purely a UX nicety.
                    if (postSuccess != null && isOwnPost(postSuccess)) {
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(
                                imageVector = Icons.Filled.MoreVert,
                                contentDescription = "Post actions",
                            )
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                        ) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.post_action_edit)) },
                                leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                                onClick = {
                                    menuExpanded = false
                                    postSuccess?.let {
                                        onEditPost(it.id, it.content)
                                    }
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.post_action_copy_link)) },
                                leadingIcon = { Icon(Icons.Filled.ContentCopy, contentDescription = null) },
                                onClick = {
                                    menuExpanded = false
                                    // Phase 3 — canonical share URL. Website uses
                                    // `${origin}/?post=${postId}` (query param on root,
                                    // not a path). We mirror that exactly so the URL
                                    // opens the app via deep-link on receivers who have
                                    // CentryChat installed, and falls back to the
                                    // website on those who don't.
                                    val url = "${BuildConfig.API_BASE_URL}/?post=${postSuccess?.id}"
                                    copyToClipboard(context, url)
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.post_link_copied),
                                        Toast.LENGTH_SHORT,
                                    ).show()
                                    // Record LINK_COPY event (analytics-only — does NOT bump shareCount).
                                    postSuccess?.let { viewModel.recordLinkCopy(it.id) }
                                },
                            )
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        stringResource(R.string.post_action_delete),
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        Icons.Filled.Delete,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                    )
                                },
                                onClick = {
                                    menuExpanded = false
                                    showDeleteDialog = true
                                },
                            )
                        }
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            CommentInputBar(
                text = commentText,
                onTextChange = { commentText = it },
                isSending = isSending,
                replyTarget = replyTarget,
                onSend = {
                    viewModel.sendComment(
                        postId = postId,
                        content = commentText,
                        parentCommentId = replyTarget?.id,
                    )
                    commentText = ""
                },
                onCancelReply = { viewModel.setReplyTarget(null) },
            )
        },
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)) {
            when (val state = postState) {
                UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                is UiState.Error -> ErrorState(message = state.message, onRetry = { viewModel.loadPost(postId) })
                is UiState.Empty -> EmptyState(message = "Post not found.")
                is UiState.Success -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        item {
                            PostHeader(
                                post = state.data,
                                onUserClick = onUserClick,
                                onLike = { viewModel.toggleLike(postId) },
                                onShare = {
                                    // Phase 3 — Share now includes the CANONICAL CentryChat URL.
                                    // Website share URL = `${origin}/?post=${postId}` (query param on root).
                                    // We mirror that exactly: https://sentrychat.netlify.app/?post={id}
                                    // This URL is what the receiver sees in their messaging app AND
                                    // what Android's deep-link system parses to open the app directly
                                    // when the receiver has CentryChat installed.
                                    val shareUrl = "${BuildConfig.API_BASE_URL}/?post=${state.data.id}"
                                    val shareText = "Check out this post by @${state.data.author.username} on CentryChat:\n${state.data.content.take(140)}\n\n$shareUrl"
                                    val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(
                                            android.content.Intent.EXTRA_SUBJECT,
                                            "@${state.data.author.username} on CentryChat",
                                        )
                                        putExtra(
                                            android.content.Intent.EXTRA_TEXT,
                                            shareText,
                                        )
                                    }
                                    // Native Android share sheet — receiver chooses WhatsApp /
                                    // Facebook / Messenger / Telegram / Gmail / Copy Link / any
                                    // installed app. NOT hard-coded to any specific package.
                                    val chooser = android.content.Intent.createChooser(shareIntent, "Share post")
                                    chooser.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    try {
                                        context.startActivity(chooser)
                                        // Record SHARE event on the backend only after
                                        // the chooser was launched (mirrors the web's
                                        // behavior — share event fires only when the
                                        // user actually opens the share dialog).
                                        viewModel.sharePost(postId)
                                    } catch (_: Exception) {
                                        // No app to handle the share intent — silently
                                        // skip (the user can retry later).
                                    }
                                },
                            )
                        }
                        item {
                            Text(
                                text = stringResource(R.string.comments_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            )
                        }
                        when (val cState = commentsState) {
                            UiState.Loading -> item {
                                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            }
                            is UiState.Error -> item {
                                ErrorState(message = cState.message, onRetry = { viewModel.loadComments(postId) })
                            }
                            UiState.Empty -> item {
                                EmptyState(message = stringResource(R.string.comments_empty))
                            }
                            is UiState.Success -> {
                                items(cState.data) { comment ->
                                    CommentRow(
                                        comment = comment,
                                        onUserClick = onUserClick,
                                        onLike = { viewModel.toggleCommentLike(comment.id) },
                                        onReply = { viewModel.setReplyTarget(comment) },
                                        canDelete = viewModel.canDeleteComment(comment),
                                        onDelete = { viewModel.deleteComment(postId, comment) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete confirmation dialog.
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(stringResource(R.string.post_delete_dialog_title)) },
            text = { Text(stringResource(R.string.post_delete_dialog_message)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        viewModel.deletePost(postId)
                    }
                ) {
                    Text(
                        stringResource(R.string.post_delete_confirm),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(stringResource(R.string.post_delete_cancel))
                }
            },
        )
    }
}

/**
 * Determines whether the currently-logged-in user is the author of the
 * given post. The backend re-checks ownership on every state-changing
 * call (PATCH / DELETE) so UI hiding is a UX nicety, not a security
 * boundary — but checking it here avoids surfacing the Edit / Delete
 * menu to non-authors (which would just 404 on the backend).
 *
 * Implementation note: we compare the post's `author.id` against the
 * current user's ID. The current user ID is stored in the
 * `SecureSessionStore` (encrypted SharedPreferences) and exposed
 * via [com.centrychat.android.data.repository.AuthRepository.currentUser].
 * We grab the AuthRepository from the [LocalAppContainer] CompositionLocal
 * set up in [com.centrychat.android.MainActivity].
 */
@Composable
private fun isOwnPost(post: PostDto): Boolean {
    val appContainer = com.centrychat.android.core.LocalAppContainer.current
    val currentUser by appContainer.authRepository.currentUser.collectAsState()
    return currentUser?.id != null && currentUser?.id == post.author.id
}

/** Helper: copy text to the system clipboard. */
private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("CentryChat post", text))
}

@Composable
private fun PostHeader(
    post: PostDto,
    onUserClick: (String) -> Unit,
    onLike: () -> Unit,
    onShare: () -> Unit = {},
) {
    Column(Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CentryChatAvatar(
                fullName = post.author.fullName,
                avatarColor = post.author.avatarColor,
                avatarUrl = post.author.avatarUrl,
                onClick = { onUserClick(post.author.username) },
                size = 44.dp,
            )
            Spacer(Modifier.size(8.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = post.author.fullName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (post.author.isVerified) {
                        Spacer(Modifier.size(4.dp))
                        VerifiedBadge()
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "@${post.author.username} · ${TimeFormatter.relative(post.createdAt)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    // ── Phase 2: "(edited)" indicator ─────────────────────────
                    // Backend sets `updatedAt = @updatedAt` (always bumped on PATCH).
                    // On a freshly-created post, `updatedAt == createdAt` (both set
                    // server-side at insert time). After an edit, `updatedAt > createdAt`.
                    // We detect edits by comparing the ISO timestamps lexicographically
                    // (which works for equal-format UTC strings — the backend always
                    // emits ISO 8601 in UTC).
                    if (isEdited(post)) {
                        Spacer(Modifier.size(4.dp))
                        Text(
                            text = "· ${stringResource(R.string.post_edited_indicator)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(text = post.content, style = MaterialTheme.typography.bodyLarge)
        // ── Inline media from Post.content URLs (Post Video fix) ─────────
        //
        // Same logic as FeedScreen.PostCard: extract URLs from post.content
        // (mirrors the website's `parsePostContent` regex at src/lib/posts/
        // parser.ts:72), pass each to UnifiedVideoPlayer which calls
        // POST /api/v1/media/resolve and dispatches by `media.type`:
        //   - "video" → ExoPlayer inline
        //   - "embed" → WebView inline (YouTube / Vimeo / TikTok / etc.)
        //   - "preview" / "unknown" → "Open original" fallback
        //
        // FILTER: only render video player widgets for URLs whose structure
        // signals video content (YouTube, Vimeo, direct .mp4/.m3u8/.mpd).
        // Non-video URLs (e.g. github.com/example) are NOT rendered as
        // players — the website renders those as plain `<a target="_blank">`
        // links, so we mirror that behavior on Android.
        //
        // Up to 6 URLs are rendered on the detail screen (vs. 4 in the
        // feed) because the detail view is the full-content view.
        val postUrls = remember(post.id, post.content) {
            com.centrychat.android.core.util.TextUtils.extractUrls(post.content)
                .filter {
                    com.centrychat.android.ui.components.VideoUrlClassifier
                        .isLikelyVideoUrl(it)
                }
                .take(6)
        }
        postUrls.forEach { url ->
            Spacer(Modifier.height(8.dp))
            com.centrychat.android.ui.components.UnifiedVideoPlayer(
                rawUrl = url,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            EngagementButton(
                icon = if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                count = post.likeCount,
                active = post.isLiked,
                onClick = onLike,
            )
            EngagementButton(
                icon = Icons.Filled.ChatBubbleOutline,
                count = post.commentCount,
            )
            EngagementButton(
                icon = Icons.Filled.Share,
                count = post.shareCount,
                onClick = onShare,
            )
        }
    }
}

/**
 * Phase 2 — detect if a post has been edited.
 *
 * The backend's Prisma schema declares `updatedAt DateTime @updatedAt`,
 * which means Prisma bumps `updatedAt` on every UPDATE. On a freshly
 * INSERTED post, Prisma sets `createdAt` and `updatedAt` to the same
 * timestamp. After a `PATCH /api/v1/posts/{id}`, `updatedAt` is bumped
 * to the current server time while `createdAt` is unchanged.
 *
 * We compare the two timestamps as strings. The backend always emits
 * ISO 8601 UTC strings (e.g. "2026-09-28T15:30:00.000Z"), so a
 * lexicographic comparison correctly determines which is later.
 *
 * Edge case: if the PATCH happens within the same millisecond as the
 * INSERT (impossible in practice — the user must navigate to the
 * composer, edit, tap Save), the timestamps would be equal and we'd
 * miss the edited indicator. This is acceptable: the spec says the
 * indicator is a UX nicety, not a correctness requirement.
 */
private fun isEdited(post: PostDto): Boolean {
    val created = post.createdAt
    val updated = post.updatedAt ?: return false
    if (created.isBlank() || updated.isBlank()) return false
    // Lexicographic comparison works for equal-format ISO 8601 UTC strings.
    return updated != created
}

@Composable
private fun EngagementButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Long,
    active: Boolean = false,
    onClick: () -> Unit = {},
) {
    IconButton(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.size(4.dp))
            Text(
                text = TextUtils.compactCount(count),
                style = MaterialTheme.typography.bodySmall,
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun CommentRow(
    comment: CommentDto,
    onUserClick: (String) -> Unit,
    onLike: () -> Unit,
    onReply: () -> Unit,
    canDelete: Boolean = false,
    onDelete: () -> Unit = {},
) {
    // Phase 3 — delete confirmation dialog state. Mirrors the website's
    // AlertDialog in src/components/comments/comment-thread.tsx:741-784.
    var showDeleteDialog by remember { mutableStateOf(false) }

    Column(Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CentryChatAvatar(
                fullName = comment.author.fullName,
                avatarColor = comment.author.avatarColor,
                avatarUrl = comment.author.avatarUrl,
                onClick = { onUserClick(comment.author.username) },
                size = 32.dp,
            )
            Spacer(Modifier.size(8.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = comment.author.fullName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (comment.author.isVerified) {
                        Spacer(Modifier.size(4.dp))
                        VerifiedBadge()
                    }
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "· ${TimeFormatter.relative(comment.createdAt)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = comment.content,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(start = 40.dp),
        )
        Spacer(Modifier.height(4.dp))
        // ── Phase 3: Comment action row — mirrors website comment-thread.tsx:699-785
        //
        // Website uses Heart (h-3.5 w-3.5 ≈ 14dp) for Like, red when active;
        // CornerDownRight for Reply; Trash2 (h-3 w-3 ≈ 12dp) for Delete,
        // only shown when canDelete. We mirror the same structure here:
        //   - Heart icon (14dp) — red-500 when liked, muted otherwise
        //   - Reply icon + "Reply" label
        //   - Trash icon (12dp) — only when canDelete (comment author OR
        //     post author OR admin/moderator)
        //
        // The website shows likeCount only when > 0. We mirror that.
        Row(
            modifier = Modifier.padding(start = 40.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            // ── Like (Heart) ────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onLike)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = if (comment.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = if (comment.isLiked) "Unlike" else "Like",
                    tint = if (comment.isLiked) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp),
                )
                if (comment.likeCount > 0) {
                    Spacer(Modifier.size(4.dp))
                    Text(
                        text = TextUtils.compactCount(comment.likeCount),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (comment.isLiked) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            // ── Reply ────────────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onReply)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Filled.Reply,
                    contentDescription = "Reply",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp),
                )
                Spacer(Modifier.size(4.dp))
                Text(
                    text = "Reply",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            // ── Delete (Trash) — only when canDelete ───────────────────
            if (canDelete) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showDeleteDialog = true }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = "Delete comment",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(12.dp),
                    )
                }
            }
        }
        if (comment.replies.isNotEmpty()) {
            Column(modifier = Modifier
                .padding(start = 40.dp, top = 8.dp)) {
                comment.replies.forEach { reply ->
                    CommentRow(
                        comment = reply,
                        onUserClick = onUserClick,
                        onLike = onLike,
                        onReply = onReply,
                        // Replies inherit canDelete from the parent context —
                        // the website passes canDelete recursively with
                        // `user?.id === reply.author.id || canDelete` so the
                        // post owner can delete any reply too.
                        canDelete = canDelete,
                        onDelete = onDelete,
                    )
                }
            }
        }
    }

    // ── Delete confirmation dialog — mirrors website AlertDialog ────
    // at src/components/comments/comment-thread.tsx:745-784.
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(stringResource(R.string.post_delete_dialog_title)) },
            text = { Text(stringResource(R.string.post_delete_dialog_message)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        onDelete()
                    }
                ) {
                    Text(
                        stringResource(R.string.post_delete_confirm),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(stringResource(R.string.post_delete_cancel))
                }
            },
        )
    }
}

@Composable
private fun TextButton(text: String, count: Long?, onClick: () -> Unit, active: Boolean = false) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = if (count != null) "$text · ${TextUtils.compactCount(count)}" else text,
            style = MaterialTheme.typography.labelMedium,
            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CommentInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    isSending: Boolean,
    replyTarget: CommentDto?,
    onSend: () -> Unit,
    onCancelReply: () -> Unit,
) {
    Column(Modifier
        .fillMaxWidth()
        .padding(8.dp)) {
        if (replyTarget != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.comments_reply_to, "@${replyTarget.author.username}"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onCancelReply) {
                    Icon(Icons.Filled.Close, contentDescription = "Cancel reply")
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.comments_input_placeholder)) },
                singleLine = false,
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                shape = RoundedCornerShape(24.dp),
            )
            Spacer(Modifier.size(8.dp))
            IconButton(
                onClick = onSend,
                enabled = text.isNotBlank() && !isSending,
            ) {
                if (isSending) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.cd_send_comment),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
    }
}
