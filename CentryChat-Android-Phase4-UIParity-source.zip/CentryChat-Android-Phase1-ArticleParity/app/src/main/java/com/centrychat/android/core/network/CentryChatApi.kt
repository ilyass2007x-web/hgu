package com.centrychat.android.core.network

import com.centrychat.android.data.model.AdminAuditListResponse
import com.centrychat.android.data.model.AdminContentListResponse
import com.centrychat.android.data.model.AdminDashboardResponse
import com.centrychat.android.data.model.AdminFeaturesResponse
import com.centrychat.android.data.model.AdminMyPermissionsResponse
import com.centrychat.android.data.model.AdminSecurityResponse
import com.centrychat.android.data.model.AdminSettingsResponse
import com.centrychat.android.data.model.AdminSystemResponse
import com.centrychat.android.data.model.AdminUserDetailResponse
import com.centrychat.android.data.model.AdminUsersListResponse
import com.centrychat.android.data.model.AdMobAppUpdateBody
import com.centrychat.android.data.model.AdMobAppUpdateResponse
import com.centrychat.android.data.model.AdMobAppsResponse
import com.centrychat.android.data.model.AdMobSettingsResponse
import com.centrychat.android.data.model.AdMobSettingsUpdateBody
import com.centrychat.android.data.model.AdUnitCreateBody
import com.centrychat.android.data.model.AdUnitResponse
import com.centrychat.android.data.model.AdUnitUpdateBody
import com.centrychat.android.data.model.AdUnitsListResponse
import com.centrychat.android.data.model.ApiResponse
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.ArticleDetailResponse
import com.centrychat.android.data.model.ArticleListResponse
import com.centrychat.android.data.model.AuthMeResponse
import com.centrychat.android.data.model.CollectionDto
import com.centrychat.android.data.model.CollectionItemsResponse
import com.centrychat.android.data.model.CollectionsListResponse
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.CommentsResponse
import com.centrychat.android.data.model.ConversationCreateResponse
import com.centrychat.android.data.model.ConversationDto
import com.centrychat.android.data.model.ConversationsListResponse
import com.centrychat.android.data.model.FeedResponse
import com.centrychat.android.data.model.ForgotPasswordRequest
import com.centrychat.android.data.model.GenericMessageResponse
import com.centrychat.android.data.model.LoginRequest
import com.centrychat.android.data.model.LoginResponse
import com.centrychat.android.data.model.MessageDto
import com.centrychat.android.data.model.MessageEnvelope
import com.centrychat.android.data.model.MessagesListResponse
import com.centrychat.android.data.model.NotificationListResponse
import com.centrychat.android.data.model.PagedPostsResponse
import com.centrychat.android.data.model.PlaylistDto
import com.centrychat.android.data.model.PlaylistDetailResponse
import com.centrychat.android.data.model.PlaylistItemsResponse
import com.centrychat.android.data.model.PlaylistsListResponse
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.PostEnvelope
import com.centrychat.android.data.model.PostViewResponse
import com.centrychat.android.data.model.ShareResponse
import com.centrychat.android.data.model.ProfileResponse
import com.centrychat.android.data.model.RegisterRequest
import com.centrychat.android.data.model.ResetPasswordRequest
import com.centrychat.android.data.model.SearchAllResponse
import com.centrychat.android.data.model.SearchHistoryResponse
import com.centrychat.android.data.model.SitePageResponse
import com.centrychat.android.data.model.SuggestResponse
import com.centrychat.android.data.model.SuggestedUsersResponse
import com.centrychat.android.data.model.TopicDetailResponse
import com.centrychat.android.data.model.TopicsListResponse
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.UserProfileResponse
import com.centrychat.android.data.model.UsernameCheckRequest
import com.centrychat.android.data.model.UsernameCheckResponse
import com.centrychat.android.data.model.UsersListResponse
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Retrofit API surface for the CentryChat backend.
 *
 * All endpoints live under `/api/v1/` on the deployed Next.js app.
 * Each endpoint returns [ApiResponse] — the backend's standard envelope
 * is `{ ok: true, data: ... }` for success and
 * `{ ok: false, error: { message, code?, detail? } }` for errors.
 *
 * CSRF: state-changing endpoints (POST/PUT/PATCH/DELETE) require an `Origin`
 * header matching the deployment URL. The [AuthInterceptor] adds this header
 * automatically for every state-changing request.
 *
 * Auth: every authenticated request automatically carries the session cookie
 * via the [PersistentCookieJar] installed on the OkHttp client.
 */
interface CentryChatApi {

    // ── Health & system ─────────────────────────────────────────────────
    @GET("api/v1/health")
    suspend fun getHealth(): ApiResponse<GenericMessageResponse>

    // ── Authentication ─────────────────────────────────────────────────

    @POST("api/v1/auth/login")
    suspend fun login(
        @Body body: LoginRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<LoginResponse>

    @POST("api/v1/auth/register")
    suspend fun register(
        @Body body: RegisterRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<LoginResponse>

    @POST("api/v1/auth/logout")
    suspend fun logout(
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/auth/me")
    suspend fun getMe(): ApiResponse<AuthMeResponse>

    @POST("api/v1/auth/forgot-password")
    suspend fun forgotPassword(
        @Body body: ForgotPasswordRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/auth/reset-password")
    suspend fun resetPassword(
        @Body body: ResetPasswordRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/auth/resend-verification")
    suspend fun resendVerification(
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Profile (current user) ─────────────────────────────────────────

    @GET("api/v1/profile")
    suspend fun getMyProfile(): ApiResponse<ProfileResponse>

    @PATCH("api/v1/profile")
    suspend fun updateMyProfile(
        @Body body: Map<String, @JvmSuppressWildcards Any?>,
        @Header("Origin") origin: String,
    ): ApiResponse<ProfileResponse>

    // ── Public profiles ────────────────────────────────────────────────

    @GET("api/v1/users/{username}/profile")
    suspend fun getUserProfile(@Path("username") username: String): ApiResponse<UserProfileResponse>

    @GET("api/v1/users/{username}/followers")
    suspend fun getFollowers(
        @Path("username") username: String,
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<UsersListResponse>

    @GET("api/v1/users/{username}/following")
    suspend fun getFollowing(
        @Path("username") username: String,
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<UsersListResponse>

    @POST("api/v1/users/{username}/follow")
    suspend fun followUser(
        @Path("username") username: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @DELETE("api/v1/users/{username}/follow")
    suspend fun unfollowUser(
        @Path("username") username: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/users/suggested")
    suspend fun getSuggestedUsers(): ApiResponse<SuggestedUsersResponse>

    @GET("api/v1/users/search")
    suspend fun searchUsers(@Query("q") query: String): ApiResponse<UsersListResponse>

    // ── Feed ───────────────────────────────────────────────────────────

    @GET("api/v1/feed/unified")
    suspend fun getUnifiedFeed(
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
        @Query("mix") mix: String? = null,
    ): ApiResponse<FeedResponse>

    @GET("api/v1/feed/trending")
    suspend fun getTrendingFeed(
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<FeedResponse>

    // ── Posts ──────────────────────────────────────────────────────────

    @GET("api/v1/posts")
    suspend fun getPosts(
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
        @Query("authorId") authorId: String? = null,
    ): ApiResponse<PagedPostsResponse>

    @POST("api/v1/posts")
    suspend fun createPost(
        @Body body: Map<String, @JvmSuppressWildcards String>,
        @Header("Origin") origin: String,
    ): ApiResponse<PostEnvelope>

    @GET("api/v1/posts/{id}")
    suspend fun getPost(@Path("id") id: String): ApiResponse<PostEnvelope>

    /**
     * Edit the content of a post owned by the current user.
     *
     * Backend: `PATCH /api/v1/posts/{id}` (see
     * src/app/api/v1/posts/[id]/route.ts). The backend enforces
     * `requireVerifiedUser()` + ownership (non-owners get 404 to avoid
     * information disclosure) + re-runs content moderation on the
     * edited text. Response wraps the updated post under `data.post`
     * (same shape as GET /api/v1/posts/{id}).
     *
     * The backend re-runs `validatePostContent` (trim + whitespace-
     * normalize → 1..280 chars) and the moderation pipeline on the
     * edited content — a user editing a clean post to prohibited
     * content is caught at this endpoint, not just at create time.
     */
    @PATCH("api/v1/posts/{id}")
    suspend fun updatePost(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String>,
        @Header("Origin") origin: String,
    ): ApiResponse<PostEnvelope>

    @DELETE("api/v1/posts/{id}")
    suspend fun deletePost(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/posts/{id}/like")
    suspend fun togglePostLike(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<ToggleLikeResponse>

    /**
     * Record a UNIQUE post view. One authenticated user = one view per post
     * (the backend's PostView table has `@@unique([postId, userId])`).
     * The author's own views are skipped server-side.
     *
     * Backend: `POST /api/v1/posts/{id}/views` (see
     * src/app/api/v1/posts/[id]/views/route.ts). Returns
     * `{ ok: true, viewCount: number }` where viewCount is the
     * server-authoritative unique-viewer count.
     *
     * The client should call this ONCE per post detail open (the
     * backend dedupes via upsert, so duplicate calls are safe but
     * wasteful).
     */
    @POST("api/v1/posts/{id}/views")
    suspend fun recordPostView(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<PostViewResponse>

    /**
     * Record a SHARE or LINK_COPY interaction event on a post. Mirrors
     * the web's ShareDialog behavior (records one event per successful
     * share / link-copy).
     *
     * Backend: `POST /api/v1/posts/{id}/share` (see
     * src/app/api/v1/posts/[id]/share/route.ts). Records a PostInteraction
     * row + increments the post's shareCount for type="SHARE" (LINK_COPY
     * is tracked separately and does NOT increment the public shareCount).
     *
     * Body: `{ type: "SHARE" | "LINK_COPY" }`.
     * Response: `{ shared: true, shareCount: number }` — `shareCount` is
     * the SERVER-AUTHORITATIVE total of SHARE interactions on this post.
     * The client uses this to reconcile its optimistic UI update.
     */
    @POST("api/v1/posts/{id}/share")
    suspend fun sharePost(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<ShareResponse>

    @GET("api/v1/posts/{id}/comments")
    suspend fun getPostComments(
        @Path("id") id: String,
        @Query("limit") limit: Int = 50,
        @Query("cursor") cursor: String? = null,
        @Query("sort") sort: String = "newest",
    ): ApiResponse<CommentsResponse>

    @POST("api/v1/posts/{id}/comments")
    suspend fun createPostComment(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<CommentDto>

    @POST("api/v1/post-comments/{id}/like")
    suspend fun toggleCommentLike(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<ToggleLikeResponse>

    /**
     * Delete a post comment (top-level OR reply at any depth).
     *
     * Backend: `DELETE /api/v1/comments/{id}` (note: comments, NOT
     * post-comments — the post-comment DELETE handler lives under
     * /api/v1/comments, not /api/v1/post-comments).
     *
     * Auth: requires authenticated + verified user.
     * Authorization (server-side, source of truth):
     *   - Comment author can delete their own comment
     *   - Post author can delete ANY comment under their own post
     *     (gives post owners moderation power — website §10)
     *   - MODERATOR / ADMIN / SUPER_ADMIN can delete any comment
     *   - Anyone else gets 404 (defense-in-depth — no info leak)
     *
     * Cascade: Prisma `onDelete: Cascade` on PostComment.replies
     * auto-removes all descendant replies + likes in one SQL op.
     *
     * Mirrors the website's CommentThread `handleDelete` flow at
     * src/components/comments/comment-thread.tsx:590-602.
     */
    @DELETE("api/v1/comments/{id}")
    suspend fun deletePostComment(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Articles ───────────────────────────────────────────────────────

    @GET("api/v1/articles")
    suspend fun getArticles(
        @Query("limit") limit: Int = 10,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<ArticleListResponse>

    /**
     * List a specific user's articles. Published articles are public;
     * drafts are visible only to the author (server enforces via session).
     *
     * Used by the Profile screen's Articles tab — the global
     * `/api/v1/articles` returns articles from ALL users, which was
     * causing the wrong user's articles to show up on Profile.
     *
     * Backend: `GET /api/v1/users/{username}/articles` →
     * `{ "ok": true, "data": { "articles": ArticleCardDto[] } }`
     */
    @GET("api/v1/users/{username}/articles")
    suspend fun getUserArticles(
        @Path("username") username: String,
        @Query("limit") limit: Int = 50,
    ): ApiResponse<ArticleListResponse>

    @GET("api/v1/articles/{id}")
    suspend fun getArticle(@Path("id") id: String): ApiResponse<ArticleDetailResponse>

    @POST("api/v1/articles/{id}/like")
    suspend fun toggleArticleLike(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<ToggleLikeResponse>

    /**
     * Record a SHARE interaction on an article. Mirrors the post share
     * endpoint's design. Body: `{ method: "native" }` (default if omitted).
     * Response: `{ shared: true, shareCount: number }`.
     *
     * Backend: `POST /api/v1/articles/{id}/share` (see
     * src/app/api/v1/articles/[id]/share/route.ts). The backend increments
     * `Article.shareCount` in a transaction + records an
     * `ArticleInteraction { type: "SHARE" }` row, then returns the
     * server-authoritative `shareCount`.
     */
    @POST("api/v1/articles/{id}/share")
    suspend fun shareArticle(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<ShareResponse>

    @GET("api/v1/articles/{id}/comments")
    suspend fun getArticleComments(
        @Path("id") id: String,
        @Query("limit") limit: Int = 50,
    ): ApiResponse<CommentsResponse>

    @POST("api/v1/articles/{id}/comments")
    suspend fun createArticleComment(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<CommentDto>

    /**
     * Toggle like on an article comment (or reply — the backend detects
     * based on parentCommentId). Mirrors the post-comment like endpoint.
     *
     * Backend: `POST /api/v1/article-comments/{id}/like` (see
     * src/app/api/v1/article-comments/[id]/like/route.ts).
     * Response: `{ liked: boolean, likeCount: number }`.
     */
    @POST("api/v1/article-comments/{id}/like")
    suspend fun toggleArticleCommentLike(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<ToggleLikeResponse>

    /**
     * Delete an article comment (top-level OR reply at any depth).
     *
     * Backend: `DELETE /api/v1/article-comments/{id}` (see
     * src/app/api/v1/article-comments/[id]/route.ts).
     *
     * Authorization (server-side, source of truth):
     *   - Comment author can delete their own comment
     *   - Article author can delete ANY comment under their own article
     *     (mirrors post-owner moderation power)
     *   - MODERATOR / ADMIN / SUPER_ADMIN can delete any comment
     *   - Anyone else gets 404 (defense-in-depth)
     *
     * Cascade: Prisma `onDelete: Cascade` on ArticleComment.replies
     * auto-removes all descendant replies + likes in one SQL op.
     *
     * Mirrors the website's ArticleCommentThread `handleDelete` flow.
     */
    @DELETE("api/v1/article-comments/{id}")
    suspend fun deleteArticleComment(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Articles — Phase 1 parity (create/edit/delete/views/related/translation/insights) ──

    /**
     * Create a new article. Mirrors the website's ArticleEditor →
     * POST /api/v1/articles. Auth required (verified email).
     *
     * Body: [com.centrychat.android.data.model.ArticleUpsertBody].
     * Response: `{ article: ArticleDetailDto }` wrapped under [com.centrychat.android.data.model.ArticleUpsertResponse].
     *
     * On success the article is either PUBLISHED (visible in feeds) or
     * DRAFT (only visible to author), depending on the `status` field.
     * The backend runs content moderation on title/content/excerpt and
     * may set `moderationStatus = "PENDING_MODERATION"` (article hidden
     * from public feeds until admin approves).
     */
    @POST("api/v1/articles")
    suspend fun createArticle(
        @Body body: com.centrychat.android.data.model.ArticleUpsertBody,
        @Header("Origin") origin: String,
    ): ApiResponse<com.centrychat.android.data.model.ArticleUpsertResponse>

    /**
     * Edit an existing article. Mirrors PATCH /api/v1/articles/{id}.
     * Auth required + ownership check (author or admin). All fields
     * optional — only changed fields are sent.
     *
     * Side effects: if title/content/excerpt changed, the backend
     * invalidates all cached translations for this article (fire-and-forget).
     */
    @PATCH("api/v1/articles/{id}")
    suspend fun updateArticle(
        @Path("id") id: String,
        @Body body: com.centrychat.android.data.model.ArticleUpsertBody,
        @Header("Origin") origin: String,
    ): ApiResponse<com.centrychat.android.data.model.ArticleUpsertResponse>

    /**
     * Delete an article. Mirrors DELETE /api/v1/articles/{id}.
     * Auth required + ownership check (author or admin).
     *
     * Backend cascades to ArticleLike, ArticleComment (+ nested replies
     * + likes), ArticleView, ArticleInteraction, ArticleTranslation,
     * PlaylistItem.
     */
    @DELETE("api/v1/articles/{id}")
    suspend fun deleteArticle(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<com.centrychat.android.data.model.ArticleDeleteResponse>

    /**
     * Record a view on an article. Mirrors POST /api/v1/articles/{id}/views.
     * PUBLIC endpoint — works for both logged-in users AND anonymous visitors.
     *
     * For anonymous visitors, the backend sets a `cc_visitor` cookie. On
     * Android we send the visitor ID via the `X-Visitor-Id` header (the
     * native equivalent — see VisitorTracker.kt).
     *
     * Idempotent: the backend dedupes by (articleId, userId) for logged-in
     * users OR (articleId, anonymousVisitorId) for anonymous visitors.
     * Returns `recorded: false` for duplicates, author self-views, bot
     * User-Agents, or rate-limited IPs.
     */
    @POST("api/v1/articles/{id}/views")
    suspend fun recordArticleView(
        @Path("id") id: String,
        @Header("X-Visitor-Id") visitorId: String? = null,
    ): ApiResponse<com.centrychat.android.data.model.ArticleViewResponse>

    /**
     * Fetch related articles for an article. Mirrors
     * GET /api/v1/articles/{id}/related?limit=5.
     * PUBLIC endpoint — no auth required.
     *
     * Backend uses a scoring algorithm (same author +5, keyword overlap
     * +5/max +20, same language +25, recent +10, high engagement +10,
     * trending +15) and returns up to 6 candidates with a `reason` field
     * explaining the match.
     */
    @GET("api/v1/articles/{id}/related")
    suspend fun getRelatedArticles(
        @Path("id") id: String,
        @Query("limit") limit: Int = 5,
    ): ApiResponse<com.centrychat.android.data.model.RelatedArticlesResponse>

    /**
     * Fetch a translation of an article. Mirrors
     * GET /api/v1/articles/{id}/translation?lang=XX.
     * PUBLIC endpoint — anonymous visitors can request translations.
     *
     * Backend uses GLM-4.6 via z-ai-web-dev-sdk and caches results
     * keyed by (articleId, languageCode) with SHA-256 source hash
     * invalidation (article edits invalidate the cache). Returns
     * `fromCache: true` when serving from cache.
     */
    @GET("api/v1/articles/{id}/translation")
    suspend fun getArticleTranslation(
        @Path("id") id: String,
        @Query("lang") lang: String,
    ): ApiResponse<com.centrychat.android.data.model.ArticleTranslationResponse>

    /**
     * Fetch engagement insights for an article. Mirrors
     * GET /api/v1/articles/{id}/insights.
     * Auth required + ownership check (author or admin) — backend
     * returns 403 Forbidden otherwise.
     *
     * Returns uniqueViews, likes, comments, shares, engagementRate,
     * and follower/nonFollower audience breakdown. trafficSources is
     * always null (backend placeholder for future).
     */
    @GET("api/v1/articles/{id}/insights")
    suspend fun getArticleInsights(
        @Path("id") id: String,
    ): ApiResponse<com.centrychat.android.data.model.ArticleInsightsResponse>

    // ── Notifications ─────────────────────────────────────────────────

    @GET("api/v1/notifications")
    suspend fun getNotifications(
        @Query("limit") limit: Int = 20,
        @Query("beforeId") beforeId: String? = null,
        @Query("unread") unread: String? = null,
    ): ApiResponse<NotificationListResponse>

    @POST("api/v1/notifications/{id}/read")
    suspend fun markNotificationRead(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/notifications/read-all")
    suspend fun markAllNotificationsRead(
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Search ────────────────────────────────────────────────────────

    @GET("api/v1/search/all")
    suspend fun searchAll(
        @Query("q") query: String,
        @Query("limit") limit: Int = 20,
        @Query("type") type: String? = null,
    ): ApiResponse<SearchAllResponse>

    @GET("api/v1/search/suggest")
    suspend fun searchSuggest(
        @Query("q") query: String,
        @Query("limit") limit: Int = 10,
    ): ApiResponse<SuggestResponse>

    @GET("api/v1/search-history")
    suspend fun getSearchHistory(): ApiResponse<SearchHistoryResponse>

    @DELETE("api/v1/search-history")
    suspend fun clearSearchHistory(
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Username check (public, real-time) ──────────────────────────

    @POST("api/v1/username-check")
    suspend fun checkUsername(
        @Body body: UsernameCheckRequest,
    ): ApiResponse<UsernameCheckResponse>

    // ── Topics ───────────────────────────────────────────────────────

    @GET("api/v1/topics")
    suspend fun getTopics(
        @Query("limit") limit: Int = 50,
    ): ApiResponse<TopicsListResponse>

    @GET("api/v1/topics/{slug}")
    suspend fun getTopic(
        @Path("slug") slug: String,
    ): ApiResponse<TopicDetailResponse>

    @GET("api/v1/topics/{slug}/content")
    suspend fun getTopicContent(
        @Path("slug") slug: String,
        @Query("limit") limit: Int = 20,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<FeedResponse>

    @POST("api/v1/topics/{slug}/follow")
    suspend fun followTopic(
        @Path("slug") slug: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @DELETE("api/v1/topics/{slug}/follow")
    suspend fun unfollowTopic(
        @Path("slug") slug: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Collections ──────────────────────────────────────────────────

    @GET("api/v1/collections")
    suspend fun getCollections(
        @Query("limit") limit: Int = 50,
    ): ApiResponse<CollectionsListResponse>

    @POST("api/v1/collections")
    suspend fun createCollection(
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<CollectionDto>

    @GET("api/v1/collections/{id}")
    suspend fun getCollection(
        @Path("id") id: String,
    ): ApiResponse<CollectionDto>

    @DELETE("api/v1/collections/{id}")
    suspend fun deleteCollection(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/collections/{id}/items")
    suspend fun getCollectionItems(
        @Path("id") id: String,
        @Query("limit") limit: Int = 50,
    ): ApiResponse<CollectionItemsResponse>

    @POST("api/v1/collections/{id}/items")
    suspend fun addCollectionItem(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @DELETE("api/v1/collections/{id}/items/{itemId}")
    suspend fun removeCollectionItem(
        @Path("id") id: String,
        @Path("itemId") itemId: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Media resolver ───────────────────────────────────────────────
    //
    // Universal media URL resolver — mirrors the website's `POST /api/v1/media/resolve`
    // (src/app/api/v1/media/resolve/route.ts). Used by [UnifiedVideoPlayer] to
    // figure out whether a `videoUrl` from an Article / Playlist item / Post
    // content is:
    //   - a direct video file (type="video") → play with ExoPlayer
    //   - a platform embed (YouTube/Vimeo/TikTok/etc., type="embed") → render in WebView
    //   - a preview/unknown (type="preview"|"unknown") → show fallback "Open original" card
    //
    // The endpoint is auth-gated (`requireUser`) — the OkHttp client's
    // PersistentCookieJar attaches the session cookie automatically + the
    // AuthInterceptor adds the Origin header on POST (CSRF check).
    //
    // Backend response:
    //   { "ok": true, "data": { "media": { "type": "...", "mediaUrl": "...", ... } } }
    // On resolver failure the backend STILL returns HTTP 200 with media.type="unknown"
    // — the call never throws for a resolver-side error, only for transport failures.

    /**
     * Resolve any URL into a [com.centrychat.android.data.model.ResolvedMediaDto].
     *
     * @param body   `{ "url": "<full URL>" }`
     * @param origin the `Origin` header (CSRF) — must match [com.centrychat.android.BuildConfig.API_ORIGIN].
     */
    @POST("api/v1/media/resolve")
    suspend fun resolveMedia(
        @Body body: com.centrychat.android.data.model.MediaResolveRequest,
        @Header("Origin") origin: String,
    ): ApiResponse<com.centrychat.android.data.model.MediaResolveResponse>

    // ── Playlists ────────────────────────────────────────────────────

    @GET("api/v1/playlists")
    suspend fun getPlaylists(
        @Query("limit") limit: Int = 50,
    ): ApiResponse<PlaylistsListResponse>

    /**
     * List a specific user's playlists for the public Profile view.
     *
     * Public endpoint — anonymous viewers see only PUBLIC playlists;
     * the owner sees all (public + private). Admins see all.
     *
     * Used by the Profile screen's Playlists tab — the global
     * `/api/v1/playlists` returns the CURRENT user's playlists only,
     * which was causing the wrong (or no) playlists to show up when
     * viewing someone else's profile.
     *
     * Backend: `GET /api/v1/users/{username}/playlists` →
     * `{ "ok": true, "data": { "playlists": PlaylistDto[],
     *                          "total": number, "page": number,
     *                          "limit": number } }`
     * The extra `total` / `page` / `limit` fields are ignored
     * (`ignoreUnknownKeys = true` in Json config).
     */
    @GET("api/v1/users/{username}/playlists")
    suspend fun getUserPlaylists(
        @Path("username") username: String,
        @Query("limit") limit: Int = 100,
        @Query("page") page: Int = 1,
    ): ApiResponse<PlaylistsListResponse>

    @POST("api/v1/playlists")
    suspend fun createPlaylist(
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<PlaylistDto>

    @GET("api/v1/playlists/{id}")
    suspend fun getPlaylist(
        @Path("id") id: String,
    ): ApiResponse<PlaylistDetailResponse>

    @DELETE("api/v1/playlists/{id}")
    suspend fun deletePlaylist(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/playlists/{id}/items")
    suspend fun getPlaylistItems(
        @Path("id") id: String,
        @Query("limit") limit: Int = 50,
    ): ApiResponse<PlaylistItemsResponse>

    @POST("api/v1/playlists/{id}/items")
    suspend fun addPlaylistItem(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @DELETE("api/v1/playlists/{id}/items/{itemId}")
    suspend fun removePlaylistItem(
        @Path("id") id: String,
        @Path("itemId") itemId: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Block / Unblock users ────────────────────────────────────────

    @POST("api/v1/users/{username}/block")
    suspend fun blockUser(
        @Path("username") username: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @DELETE("api/v1/users/{username}/block")
    suspend fun unblockUser(
        @Path("username") username: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Not-interested (feed item dismiss) ───────────────────────────

    @POST("api/v1/not-interested")
    suspend fun markNotInterested(
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Interactions (view tracking) ────────────────────────────────

    @POST("api/v1/interactions")
    suspend fun trackInteraction(
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/presence/heartbeat")
    suspend fun heartbeat(
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Public site pages (about / privacy / terms) ─────────────────

    @GET("api/v1/site-pages/{slug}")
    suspend fun getSitePage(
        @Path("slug") slug: String,
    ): ApiResponse<SitePageResponse>

    // ── Admin (role-gated — server enforces ADMIN/SUPER_ADMIN) ──────
    // NOTE: even if a non-admin user calls these, the backend returns
    // HTTP 403 + {"ok":false,"error":{"message":"Forbidden"}}. The
    // Android client gates the UI on the user's role locally AND
    // relies on the server-side check as the source of truth.

    @GET("api/v1/admin/dashboard")
    suspend fun adminGetDashboard(): ApiResponse<AdminDashboardResponse>

    @GET("api/v1/admin/users")
    suspend fun adminGetUsers(
        @Query("limit") limit: Int = 50,
        @Query("cursor") cursor: String? = null,
        @Query("search") search: String? = null,
    ): ApiResponse<AdminUsersListResponse>

    @GET("api/v1/admin/users/{id}")
    suspend fun adminGetUser(
        @Path("id") id: String,
    ): ApiResponse<AdminUserDetailResponse>

    @POST("api/v1/admin/users/{id}/action")
    suspend fun adminUserAction(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @POST("api/v1/admin/users/{id}/verify")
    suspend fun adminVerifyUser(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/admin/content")
    suspend fun adminGetContent(
        @Query("limit") limit: Int = 50,
        @Query("cursor") cursor: String? = null,
        @Query("type") type: String? = null,
    ): ApiResponse<AdminContentListResponse>

    @POST("api/v1/admin/content/{id}/action")
    suspend fun adminContentAction(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/admin/settings")
    suspend fun adminGetSettings(): ApiResponse<AdminSettingsResponse>

    @GET("api/v1/admin/features")
    suspend fun adminGetFeatures(): ApiResponse<AdminFeaturesResponse>

    @GET("api/v1/admin/audit")
    suspend fun adminGetAudit(
        @Query("limit") limit: Int = 50,
        @Query("cursor") cursor: String? = null,
    ): ApiResponse<AdminAuditListResponse>

    @GET("api/v1/admin/system")
    suspend fun adminGetSystem(): ApiResponse<AdminSystemResponse>

    @GET("api/v1/admin/security")
    suspend fun adminGetSecurity(): ApiResponse<AdminSecurityResponse>

    @GET("api/v1/admin/me/permissions")
    suspend fun adminGetMyPermissions(): ApiResponse<AdminMyPermissionsResponse>

    @POST("api/v1/admin/notifications/broadcast")
    suspend fun adminBroadcastNotification(
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    // ── Admin: Publishing & Ad Units (replaces web "AdMob" section) ──
    // These endpoints are SHARED with the web admin — the same backend
    // `/api/v1/admin/admob/*` routes serve both clients. Edits from
    // Android appear in the web admin instantly (and vice versa).
    // Permission gating: ADS_VIEW to read, ADS_MANAGE to write.
    @GET("api/v1/admin/admob/units")
    suspend fun adminGetAdUnits(
        @Query("platform") platform: String? = null,
        @Query("search") search: String? = null,
        @Query("status") status: String? = null,
        @Query("placement") placement: String? = null,
        @Query("format") format: String? = null,
    ): ApiResponse<AdUnitsListResponse>

    @POST("api/v1/admin/admob/units")
    suspend fun adminCreateAdUnit(
        @Body body: AdUnitCreateBody,
        @Header("Origin") origin: String,
    ): ApiResponse<AdUnitResponse>

    @GET("api/v1/admin/admob/units/{id}")
    suspend fun adminGetAdUnit(
        @Path("id") id: String,
    ): ApiResponse<AdUnitResponse>

    @PATCH("api/v1/admin/admob/units/{id}")
    suspend fun adminUpdateAdUnit(
        @Path("id") id: String,
        @Body body: AdUnitUpdateBody,
        @Header("Origin") origin: String,
    ): ApiResponse<AdUnitResponse>

    @DELETE("api/v1/admin/admob/units/{id}")
    suspend fun adminDeleteAdUnit(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @GET("api/v1/admin/admob/apps")
    suspend fun adminGetAdMobApps(): ApiResponse<AdMobAppsResponse>

    @PUT("api/v1/admin/admob/apps")
    suspend fun adminUpdateAdMobApp(
        @Body body: AdMobAppUpdateBody,
        @Header("Origin") origin: String,
    ): ApiResponse<AdMobAppUpdateResponse>

    @GET("api/v1/admin/admob/settings")
    suspend fun adminGetAdMobSettings(): ApiResponse<AdMobSettingsResponse>

    @PUT("api/v1/admin/admob/settings")
    suspend fun adminUpdateAdMobSettings(
        @Body body: AdMobSettingsUpdateBody,
        @Header("Origin") origin: String,
    ): ApiResponse<AdMobSettingsResponse>

    // ── Messaging (DMs — 1:1 conversations) ─────────────────────────
    // The web app uses socket.io for real-time (typing indicators,
    // presence, message arrival). The Android app uses a polling
    // fallback (every 15s) — this is acceptable for v1 and the web's
    // MainNav does the same polling for the unread-count badge.
    // Real-time socket.io integration is tracked as a follow-up.

    @GET("api/v1/conversations")
    suspend fun getConversations(): ApiResponse<ConversationsListResponse>

    @POST("api/v1/conversations")
    suspend fun createConversation(
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<ConversationCreateResponse>

    @GET("api/v1/conversations/{id}")
    suspend fun getConversation(
        @Path("id") id: String,
    ): ApiResponse<ConversationDto>

    @GET("api/v1/conversations/{id}/messages")
    suspend fun getMessages(
        @Path("id") id: String,
        @Query("limit") limit: Int = 50,
        @Query("beforeId") beforeId: String? = null,
    ): ApiResponse<MessagesListResponse>

    @POST("api/v1/conversations/{id}/messages")
    suspend fun sendMessage(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<MessageEnvelope>

    @POST("api/v1/conversations/{id}/messages/read")
    suspend fun markConversationRead(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @PATCH("api/v1/messages/{id}")
    suspend fun editMessage(
        @Path("id") id: String,
        @Body body: Map<String, @JvmSuppressWildcards String?>,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>

    @DELETE("api/v1/messages/{id}")
    suspend fun deleteMessage(
        @Path("id") id: String,
        @Header("Origin") origin: String,
    ): ApiResponse<GenericMessageResponse>
}
