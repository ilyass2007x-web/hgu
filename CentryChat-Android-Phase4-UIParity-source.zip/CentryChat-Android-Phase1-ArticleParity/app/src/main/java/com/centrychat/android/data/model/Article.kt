package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Article DTOs.
 *
 * Mirror the shapes returned by `src/app/api/v1/articles/route.ts`
 * (list endpoint) and `src/app/api/v1/articles/[id]/route.ts` (detail).
 */

@Serializable
data class ArticleCardDto(
    val id: String,
    val title: String,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("readingTime") val readingTime: Int? = null,
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("commentCount") val commentCount: Long = 0,
    @SerialName("viewCount") val viewCount: Long = 0,
    @SerialName("shareCount") val shareCount: Long = 0,
    @SerialName("isLiked") val isLiked: Boolean = false,
)

@Serializable
data class ArticleDetailDto(
    val id: String,
    val title: String,
    val content: String,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("showCoverInArticle") val showCoverInArticle: Boolean = true,
    @SerialName("adsEnabled") val adsEnabled: Boolean = true,
    val status: String = "PUBLISHED",
    @SerialName("moderationStatus") val moderationStatus: String = "APPROVED",
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("readingTime") val readingTime: Int? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String = "",
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("commentCount") val commentCount: Long = 0,
    @SerialName("viewCount") val viewCount: Long = 0,
    @SerialName("shareCount") val shareCount: Long = 0,
    @SerialName("isLiked") val isLiked: Boolean = false,
    @SerialName("topicIds") val topicIds: List<String> = emptyList(),
)

@Serializable
data class ArticleListResponse(
    val articles: List<ArticleCardDto>,
    @SerialName("nextCursor") val nextCursor: String? = null,
)

/**
 * Response wrapper for `GET /api/v1/articles/{id}` (article detail).
 *
 * The backend returns:
 *   `{ "ok": true, "data": { "article": { id, title, content, author, ... } } }`
 *
 * The inner `article` object IS the [ArticleDetailDto]. Without this
 * wrapper, kotlinx-serialization tried to deserialize `data` directly into
 * `ArticleDetailDto` and crashed with:
 *   `Fields [id, title, content, author] are required for type with serial
 *    name 'ArticleDetailDto', but they were missing at path: $.data`
 * because `data` actually contains an `article` field, not the article's
 * fields directly.
 *
 * Captured via curl on 2026-09-28 against the production backend:
 *   curl https://sentrychat.netlify.app/api/v1/articles/cmsmg2gql0010ffvw5atpn54k
 *   → {"ok":true,"data":{"article":{"id":"...","title":"...","content":"<h1>...",
 *      "author":{...},"_count":{"likes":0,...},"likeCount":0,...}}}
 *
 * The `_count` field is silently dropped because `ignoreUnknownKeys = true`
 * in RetrofitFactory — the counts are duplicated as `likeCount`,
 * `commentCount`, `viewCount`, `shareCount` at the top level of the
 * article object (which ARE in [ArticleDetailDto]).
 */
@Serializable
data class ArticleDetailResponse(
    val article: ArticleDetailDto,
)

// ──────────────────────────────────────────────────────────────────────────
// PHASE 1 — ARTICLE PARITY DTOs
// ──────────────────────────────────────────────────────────────────────────
// These DTOs mirror the backend endpoints documented in the website audit:
//   - POST   /api/v1/articles                  → createArticle
//   - PATCH  /api/v1/articles/{id}             → updateArticle
//   - DELETE /api/v1/articles/{id}            → deleteArticle
//   - POST   /api/v1/articles/{id}/views      → recordArticleView
//   - GET    /api/v1/articles/{id}/related    → listRelatedArticles
//   - GET    /api/v1/articles/{id}/translation?lang=XX → getTranslation
//   - GET    /api/v1/articles/{id}/insights    → getInsights (author-only)
//
// All wrappers follow the existing pattern (backend wraps payload under
// `data.<key>`, the repository extracts it after safeApiCall).

/**
 * Response for `GET /api/v1/articles/{id}/related?limit=5`.
 *
 * Backend returns `{ articles: RelatedArticleDto[] }` — empty array (not
 * error) when no candidates are available.
 *
 * `reason` is the human-readable match explanation ("Same author",
 * "Similar topic", "Trending", "Fresh", or null).
 */
@Serializable
data class RelatedArticleDto(
    val id: String,
    val title: String,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("readingTime") val readingTime: Int = 1,
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("commentCount") val commentCount: Long = 0,
    @SerialName("viewCount") val viewCount: Long = 0,
    @SerialName("shareCount") val shareCount: Long = 0,
    val reason: String? = null,
)

@Serializable
data class RelatedArticlesResponse(
    val articles: List<RelatedArticleDto> = emptyList(),
)

/**
 * Response for `GET /api/v1/articles/{id}/translation?lang=XX`.
 *
 * Backend returns `{ translation: ArticleTranslationDto }` where the
 * translation includes the translated title, excerpt, content, the
 * language's native name, text direction (ltr/rtl), and a `fromCache`
 * flag (cached translations return instantly).
 *
 * The translation endpoint is PUBLIC — anonymous visitors can request
 * translations. Backend uses GLM-4.6 via z-ai-web-dev-sdk and caches
 * results keyed by (articleId, languageCode) with SHA-256 source hash
 * invalidation (article edits invalidate the cache).
 */
@Serializable
data class ArticleTranslationDto(
    @SerialName("articleId") val articleId: String,
    @SerialName("languageCode") val languageCode: String,
    @SerialName("translatedTitle") val translatedTitle: String,
    @SerialName("translatedDescription") val translatedDescription: String? = null,
    @SerialName("translatedContent") val translatedContent: String,
    @SerialName("languageNativeName") val languageNativeName: String,
    @SerialName("dir") val dir: String = "ltr",
    @SerialName("fromCache") val fromCache: Boolean = false,
)

@Serializable
data class ArticleTranslationResponse(
    val translation: ArticleTranslationDto,
)

/**
 * Response for `GET /api/v1/articles/{id}/insights` (author-only).
 *
 * Backend returns engagement metrics for the article's author:
 *   - uniqueViews (count of distinct ArticleView rows — one per user OR
 *     per anonymous visitor token).
 *   - likes, comments, shares (denormalized counters).
 *   - engagementRate = (likes + comments + shares) / uniqueViews × 100.
 *   - audience breakdown: followerViews vs nonFollowerViews.
 *   - trafficSources: always null (not yet implemented on backend).
 *
 * Authorization: requires the logged-in user to be the article's author
 * OR an admin. Otherwise the backend returns 403 Forbidden.
 */
@Serializable
data class ArticleInsightsArticleDto(
    val id: String,
    val title: String,
    val excerpt: String? = null,
    @SerialName("publishedAt") val publishedAt: String? = null,
)

@Serializable
data class ArticleInsightsMetricsDto(
    @SerialName("uniqueViews") val uniqueViews: Long = 0,
    @SerialName("likes") val likes: Long = 0,
    @SerialName("comments") val comments: Long = 0,
    @SerialName("shares") val shares: Long = 0,
    @SerialName("engagementRate") val engagementRate: Double = 0.0,
)

@Serializable
data class ArticleInsightsAudienceDto(
    @SerialName("followerViews") val followerViews: Long = 0,
    @SerialName("nonFollowerViews") val nonFollowerViews: Long = 0,
    @SerialName("followerPercentage") val followerPercentage: Double = 0.0,
    @SerialName("nonFollowerPercentage") val nonFollowerPercentage: Double = 0.0,
)

@Serializable
data class ArticleInsightsResponse(
    val article: ArticleInsightsArticleDto,
    val metrics: ArticleInsightsMetricsDto,
    val audience: ArticleInsightsAudienceDto,
    // trafficSources is always null on the backend (placeholder for future).
    val trafficSources: String? = null,
)

/**
 * Response for `POST /api/v1/articles/{id}/views` (PUBLIC — no auth).
 *
 * The backend records a unique view per (article, user) OR (article,
 * anonymous visitor token). Returns whether the view was recorded
 * (false if it was a duplicate / bot / author self-view / rate-limited)
 * and the updated viewCount.
 *
 * For anonymous visitors, the backend sets a `cc_visitor` cookie. On
 * Android, we send the visitor ID via the `X-Visitor-Id` header (the
 * backend accepts either the cookie or the header — see
 * VisitorTracker.kt for the native equivalent).
 */
@Serializable
data class ArticleViewResponse(
    @SerialName("recorded") val recorded: Boolean,
    @SerialName("viewCount") val viewCount: Long,
    @SerialName("rateLimited") val rateLimited: Boolean = false,
)

/**
 * Response for `DELETE /api/v1/articles/{id}`.
 *
 * Backend returns `{ deleted: true, id: "..." }` on success.
 */
@Serializable
data class ArticleDeleteResponse(
    val deleted: Boolean = false,
    val id: String? = null,
)

/**
 * Request body for `POST /api/v1/articles` (create) and
 * `PATCH /api/v1/articles/{id}` (edit).
 *
 * For PATCH, all fields are optional — only changed fields are sent.
 * Sending `coverImage: ""` clears the cover; `videoUrl: ""` clears the
 * video; `topicIds: []` clears all topics.
 *
 * Field validation (mirrors the website's article-editor.tsx):
 *   - title: 3-200 chars (required on create)
 *   - content: min 10 chars (required on create)
 *   - excerpt: max 300 chars (optional)
 *   - status: "PUBLISHED" or "DRAFT" (default DRAFT on create)
 *   - coverImage: Pinterest or direct image URL (server validates via
 *     SSRF-safe probe + Content-Type sniff)
 *   - videoUrl: YouTube/Vimeo/TikTok/etc. embed OR direct video URL
 *   - imageZoom: 1.0-3.0 (step 0.05)
 *   - imagePositionX/Y: -1.0 to 1.0 (step 0.01)
 *   - showCoverInArticle: boolean (default true)
 */
@Serializable
data class ArticleUpsertBody(
    val title: String? = null,
    val content: String? = null,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    val status: String? = null,
    @SerialName("showCoverInArticle") val showCoverInArticle: Boolean? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("topicIds") val topicIds: List<String>? = null,
)

/**
 * Response wrapper for `POST /api/v1/articles` and `PATCH /api/v1/articles/{id}`.
 *
 * Backend returns `{ article: ArticleDetailDto }` — same shape as the
 * detail endpoint, with the new/updated fields + server-computed
 * readingTime.
 */
@Serializable
data class ArticleUpsertResponse(
    val article: ArticleDetailDto,
)
