package com.centrychat.android.feature.post_composer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.data.repository.PostsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Post composer ViewModel — creates/edits short text posts.
 *
 * POST   /api/v1/posts          { content }              → creates new post
 * PATCH  /api/v1/posts/{id}     { content }              → edits existing post
 *
 * The backend enforces `requireVerifiedUser()` + content moderation on
 * both endpoints. POST is rate-limited. PATCH re-runs the moderation
 * pipeline on the edited text (catches users who edit a clean post to
 * prohibited content).
 *
 * EDIT MODE: when [loadForEdit] is called with a postId, the VM fetches
 * the post's current content from the backend and exposes it via
 * [initialContent] so the screen can pre-load the text field. The user
 * edits, taps "Save", and the VM calls [update]. The screen observes
 * [successEvent] and pops back to the post detail screen (which
 * re-fetches the post to show the updated text + the "(edited)" badge).
 */
class PostComposerViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: PostsRepository = appContainer.postsRepository

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _successEvent = MutableStateFlow<ComposeSuccess?>(null)
    val successEvent: StateFlow<ComposeSuccess?> = _successEvent.asStateFlow()

    /** The existing post's content, loaded when entering edit mode. */
    private val _initialContent = MutableStateFlow("")
    val initialContent: StateFlow<String> = _initialContent.asStateFlow()

    /** Whether the post content has finished loading (edit mode only). */
    private val _isContentLoaded = MutableStateFlow(false)
    val isContentLoaded: StateFlow<Boolean> = _isContentLoaded.asStateFlow()

    fun consumeSuccess() { _successEvent.value = null }

    /**
     * Phase 2 — load an existing post's content for editing.
     *
     * Called by the composer screen's LaunchedEffect when [editPostId]
     * is non-null. Fetches the post via `GET /api/v1/posts/{id}` and
     * exposes its content via [initialContent] so the text field can
     * be pre-populated.
     *
     * The backend enforces ownership on the subsequent PATCH — a
     * non-owner CAN read a post but will get 404 on the edit. We
     * surface the read content here so the user can see what they're
     * about to edit; the actual edit attempt will fail at the backend
     * if they're not the author (and the screen will show the error
     * via [error]).
     */
    fun loadForEdit(postId: String) {
        if (_isContentLoaded.value) return
        viewModelScope.launch {
            try {
                val post = repo.getPost(postId)
                _initialContent.value = post.content
                _isContentLoaded.value = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not load post for editing."
                // Even on failure, mark content as loaded so the screen
                // doesn't stay in a perpetual loading state — the user
                // can dismiss the error + start typing fresh content.
                _isContentLoaded.value = true
            }
        }
    }

    /** Create a new post. Returns when published. */
    fun publish(content: String) {
        if (_isLoading.value) return
        if (content.isBlank()) {
            _error.value = "Post cannot be empty."
            return
        }
        _isLoading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                repo.createPost(content = content.trim())
                _successEvent.value = ComposeSuccess.Created
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not publish post."
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Update an existing post (author-only). Mirrors the website's
     * `PATCH /api/v1/posts/{id}` flow:
     *   - Caller pre-loads the existing post's content into the text
     *     field before navigating to the composer (via [loadForEdit]).
     *   - User edits, taps "Save".
     *   - On success, the composer pops back to the post detail screen,
     *     which re-fetches the post to show the updated text + the
     *     "(edited)" indicator (driven by `updatedAt > createdAt`).
     *
     * @param postId the post ID to edit (must be owned by the current user).
     * @param content the new content (1..280 chars after trim).
     */
    fun update(postId: String, content: String) {
        if (_isLoading.value) return
        if (content.isBlank()) {
            _error.value = "Post cannot be empty."
            return
        }
        _isLoading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                repo.updatePost(id = postId, content = content.trim())
                _successEvent.value = ComposeSuccess.Edited(postId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not update post."
            } finally {
                _isLoading.value = false
            }
        }
    }
}

/** Discriminated success event so the screen knows whether to pop or refresh. */
sealed class ComposeSuccess {
    /** A new post was created — pop back to the feed (which refreshes). */
    object Created : ComposeSuccess()

    /** An existing post was edited — pop back to its detail screen. */
    data class Edited(val postId: String) : ComposeSuccess()
}
