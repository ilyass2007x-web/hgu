package com.centrychat.android.feature.post_composer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.rememberPostComposerViewModel

/**
 * The Post composer screen — creates OR edits a short text post.
 *
 * CREATE MODE: [editPostId] is null → calls `publish(content)`.
 * EDIT MODE:   [editPostId] is non-null + [initialContent] is the
 *              post's current text → calls `update(editPostId, content)`.
 *              Pre-loads [initialContent] into the text field.
 *
 * Mirrors the website's `/compose` (create) and `/post/{id}/edit` (edit)
 * flows — both use the same composer UI, only the submit button text +
 * the underlying API call differ.
 *
 * Backend contract:
 *   - CREATE:  POST   /api/v1/posts          { content } → 201
 *   - EDIT:    PATCH  /api/v1/posts/{id}     { content } → 200
 *
 * The backend re-runs `validatePostContent` (1..280 chars after trim +
 * whitespace-normalize) and the moderation pipeline on both endpoints.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostComposerScreen(
    onPublished: () -> Unit,
    onBack: () -> Unit,
    editPostId: String? = null,
    initialContent: String = "",
) {
    val viewModel = rememberPostComposerViewModel()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val error by viewModel.error.collectAsStateWithLifecycle()
    val successEvent by viewModel.successEvent.collectAsStateWithLifecycle()
    val loadedInitialContent by viewModel.initialContent.collectAsStateWithLifecycle()
    val isContentLoaded by viewModel.isContentLoaded.collectAsStateWithLifecycle()

    val isEditMode = editPostId != null

    // In edit mode, fetch the post's existing content so we can pre-load
    // the text field. The backend's GET endpoint is public (any logged-in
    // user can read any post), but the subsequent PATCH enforces ownership.
    LaunchedEffect(editPostId) {
        if (editPostId != null) {
            viewModel.loadForEdit(editPostId)
        }
    }

    // Use rememberSaveable so the text survives config changes (rotation).
    // In edit mode we wait for the post content to load before showing
    // the field (so the user sees their existing text immediately).
    // Once loaded, we seed the saveable with the existing content.
    var content by rememberSaveable {
        mutableStateOf(initialContent)
    }
    // When the loaded content arrives (edit mode), seed the field ONCE.
    LaunchedEffect(isContentLoaded, loadedInitialContent) {
        if (isEditMode && isContentLoaded && content.isEmpty() && loadedInitialContent.isNotEmpty()) {
            content = loadedInitialContent
        }
    }

    LaunchedEffect(successEvent) {
        val event = successEvent ?: return@LaunchedEffect
        viewModel.consumeSuccess()
        when (event) {
            is ComposeSuccess.Created -> onPublished()
            is ComposeSuccess.Edited -> onPublished()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        stringResource(
                            if (isEditMode) R.string.post_composer_edit_title
                            else R.string.post_composer_title
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp)
        ) {
            // In edit mode, show a loading spinner while the existing
            // post's content is being fetched.
            if (isEditMode && !isContentLoaded) {
                Box(
                    modifier = Modifier.fillMaxWidth().height(200.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            } else {
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    placeholder = { Text(stringResource(R.string.post_composer_placeholder)) },
                    modifier = Modifier.fillMaxWidth().height(200.dp),
                    isError = error != null,
                )
            }
            error?.let { msg ->
                Spacer(Modifier.height(8.dp))
                Text(msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.padding(end = 16.dp))
                }
                Button(
                    onClick = {
                        if (isEditMode && editPostId != null) {
                            viewModel.update(editPostId, content)
                        } else {
                            viewModel.publish(content)
                        }
                    },
                    enabled = !isLoading && content.isNotBlank(),
                ) {
                    Text(
                        stringResource(
                            if (isEditMode) R.string.post_composer_save
                            else R.string.post_composer_publish
                        )
                    )
                }
            }
        }
    }
}
