package com.centrychat.android.feature.post_detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.repository.PostsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * The post-detail + comments ViewModel.
 *
 * Loads a single post + its comments in parallel. Supports:
 *  - Posting a new top-level comment
 *  - Posting a reply (with a parentCommentId)
 *  - Toggling like on a comment
 *  - Optimistic like on the post itself (with rollback on failure)
 *  - Recording a UNIQUE post view (one per user — backend dedupes)
 *  - Deleting the post (author-only — backend enforces ownership)
 *
 * Phase 2 changes (Post Parity):
 *   - `toggleLike` is now OPTIMISTIC: the UI flips immediately, the
 *     backend call fires in the background, and on failure the UI
 *     rolls back to the previous state + emits a snackbar event.
 *     Mirrors the website's `useContentStore` optimistic-toggle behavior.
 *   - `deletePost` calls `DELETE /api/v1/posts/{id}` (backend enforces
 *     author-only — non-owners get 404 to avoid leaking existence).
 *   - `recordView` calls `POST /api/v1/posts/{id}/views` once per
 *     post-detail open (backend dedupes via `@@unique([postId,userId])`,
 *     author's own views are skipped).
 *   - `sharePost` and `sendComment` now surface failures via
 *     [events] so the screen can show a snackbar (was silently caught).
 */
class PostDetailViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: PostsRepository = appContainer.postsRepository
    /** Auth repo — used to compute `canDelete` (comment author OR post
     *  author OR admin can delete; anyone else cannot). Mirrors the
     *  website's `canDelete = user?.id === c.author.id || user?.id ===
     *  postAuthorId || role === ADMIN/SUPER_ADMIN` logic at
     *  src/components/posts/comments-page.tsx:438-446. */
    private val authRepo = appContainer.authRepository

    private val _postState = MutableStateFlow<UiState<PostDto>>(UiState.Loading)
    val postState: StateFlow<UiState<PostDto>> = _postState.asStateFlow()

    private val _commentsState = MutableStateFlow<UiState<List<CommentDto>>>(UiState.Loading)
    val commentsState: StateFlow<UiState<List<CommentDto>>> = _commentsState.asStateFlow()

    private val _isSendingComment = MutableStateFlow(false)
    val isSendingComment: StateFlow<Boolean> = _isSendingComment.asStateFlow()

    private val _replyTarget = MutableStateFlow<CommentDto?>(null)
    val replyTarget: StateFlow<CommentDto?> = _replyTarget.asStateFlow()

    // Phase 2: delete flag — observed by the screen to pop back on success.
    private val _deleted = MutableStateFlow(false)
    val deleted: StateFlow<Boolean> = _deleted.asStateFlow()

    // Phase 2: transient UI events (snackbar messages).
    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val events: SharedFlow<String> = _events.asSharedFlow()

    // Track in-flight like request to debounce rapid double-taps.
    private var likeInFlight = false

    fun loadPost(postId: String) {
        _postState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val post = repo.getPost(postId)
                _postState.value = UiState.Success(post)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _postState.value = UiState.Error(e.message ?: "Could not load post.")
            }
        }
    }

    fun loadComments(postId: String) {
        _commentsState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val response = repo.getComments(postId = postId, limit = 100)
                _commentsState.value = if (response.comments.isEmpty()) {
                    UiState.Empty
                } else {
                    UiState.Success(response.comments)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _commentsState.value = UiState.Error(e.message ?: "Could not load comments.")
            }
        }
    }

    /**
     * Phase 2 — record a UNIQUE post view. The backend dedupes via
     * `@@unique([postId, userId])` on PostView + skips the author's own
     * views entirely. Safe to call once per post-detail open; duplicate
     * calls are silently no-ops server-side.
     *
     * On success, the post's `viewCount` is reconciled with the
     * server-authoritative total returned by the backend.
     */
    fun recordView(postId: String) {
        viewModelScope.launch {
            try {
                val result = repo.recordPostView(postId)
                val current = (_postState.value as? UiState.Success)?.data ?: return@launch
                _postState.value = UiState.Success(
                    current.copy(viewCount = result.viewCount)
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — view tracking is analytics-only, never blocks UX
            }
        }
    }

    /**
     * Phase 2 — OPTIMISTIC like toggle with rollback.
     *
     *  1. Flip the post's `isLiked` + adjust `likeCount` immediately so
     *     the UI feels instant (matches the website's `useContentStore`).
     *  2. Fire the backend `POST /api/v1/posts/{id}/like` call.
     *  3. On success, reconcile with the server-authoritative
     *     `(liked, likeCount)` returned by the backend.
     *  4. On failure, roll back to the pre-toggle state + emit a
     *     snackbar event so the user knows the action didn't stick.
     *
     * Debounces rapid double-taps via [likeInFlight] — the second tap
     * during an in-flight request is silently ignored (mirrors the
     * website's `shareLoading` button-disable pattern).
     */
    fun toggleLike(postId: String) {
        if (likeInFlight) return
        val current = (_postState.value as? UiState.Success)?.data ?: return

        // Snapshot for rollback.
        val previousLiked = current.isLiked
        val previousCount = current.likeCount

        // Optimistic flip.
        val optimistic = current.copy(
            isLiked = !previousLiked,
            likeCount = (previousCount + if (previousLiked) -1 else 1).coerceAtLeast(0),
        )
        _postState.value = UiState.Success(optimistic)
        likeInFlight = true

        viewModelScope.launch {
            try {
                val result = repo.toggleLike(postId)
                // Reconcile with server-authoritative state.
                _postState.value = UiState.Success(
                    optimistic.copy(isLiked = result.liked, likeCount = result.likeCount)
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // Rollback on failure.
                _postState.value = UiState.Success(
                    current.copy(isLiked = previousLiked, likeCount = previousCount)
                )
                _events.tryEmit("Could not update like — please try again.")
            } finally {
                likeInFlight = false
            }
        }
    }

    /**
     * Record a SHARE interaction on the post. Calls the backend's
     * `POST /api/v1/posts/{id}/share` endpoint (type="SHARE") and
     * reconciles the post's shareCount with the server-authoritative
     * total returned by the backend.
     *
     * The caller (the screen) is responsible for invoking the Android
     * system share sheet BEFORE calling this — the backend records the
     * event only when the share was actually performed (mirrors the
     * web's behavior in `src/components/posts/share-dialog.tsx`).
     */
    fun sharePost(postId: String) {
        viewModelScope.launch {
            try {
                val result = repo.sharePost(postId, type = "SHARE")
                val current = (_postState.value as? UiState.Success)?.data ?: return@launch
                _postState.value = UiState.Success(
                    current.copy(shareCount = result.shareCount)
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — don't surface share-tracking errors
                // (the user successfully shared; we just couldn't record
                // the event — same behavior as the web).
            }
        }
    }

    /**
     * Phase 2 — record a LINK_COPY interaction. The backend tracks this
     * as a separate PostInteraction row (type="LINK_COPY") that does
     * NOT count toward the public shareCount (only "SHARE" events do).
     * Mirrors the website's `copy-link` button behavior.
     */
    fun recordLinkCopy(postId: String) {
        viewModelScope.launch {
            try {
                repo.sharePost(postId, type = "LINK_COPY")
                // No shareCount reconciliation — LINK_COPY doesn't bump the public counter.
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — link copy tracking is analytics-only
            }
        }
    }

    fun toggleCommentLike(commentId: String) {
        viewModelScope.launch {
            try {
                val result = repo.toggleCommentLike(commentId)
                val current = (_commentsState.value as? UiState.Success)?.data ?: return@launch
                val updated = current.map { c ->
                    if (c.id == commentId) {
                        c.copy(isLiked = result.liked, likeCount = result.likeCount)
                    } else c
                }
                _commentsState.value = UiState.Success(updated)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    /**
     * Phase 3 — Compute whether the current user can delete a given comment.
     *
     * Mirrors the website's `canDelete` logic at
     * src/components/posts/comments-page.tsx:438-446:
     *   canDelete = user?.id === c.author.id ||
     *              user?.id === postAuthorId ||
     *              user?.role === "ADMIN" ||
     *              user?.role === "SUPER_ADMIN"
     *
     * The backend independently enforces all of this — the UI hiding
     * is a UX nicety, not a security boundary. Non-authorized users
     * who somehow trigger the DELETE call get 404 (defense-in-depth).
     */
    fun canDeleteComment(comment: CommentDto): Boolean {
        val user = authRepo.currentUser.value ?: return false
        val postAuthorId = (_postState.value as? UiState.Success)?.data?.author?.id
        return user.id == comment.author.id ||
            user.id == postAuthorId ||
            user.role == "ADMIN" ||
            user.role == "SUPER_ADMIN" ||
            user.role == "MODERATOR"
    }

    /**
     * Phase 3 — Delete a comment (author OR post-owner OR admin).
     *
     * Non-optimistic: waits for the server to confirm before removing
     * the comment from local state. Mirrors the website's `handleDelete`
     * at src/components/comments/comment-thread.tsx:590-602 (also non-
     * optimistic — uses `deleting` flag, removes on success, shows
     * toast on error).
     *
     * Cascade: Prisma `onDelete: Cascade` on PostComment.replies
     * auto-removes all descendant replies + likes server-side. We
     * remove the comment from the local list (including any replies
     * nested under it) + decrement the post's commentCount by the
     * total number of removed comments (1 + comment.replies.size,
     * recursively).
     *
     * On failure, emits a snackbar event + leaves the comment in
     * place (user can retry).
     */
    fun deleteComment(postId: String, comment: CommentDto) {
        viewModelScope.launch {
            try {
                repo.deleteComment(comment.id)
                // Remove the comment (and any nested replies) from local state.
                val current = (_commentsState.value as? UiState.Success)?.data ?: return@launch
                val updated = current.filter { it.id != comment.id }
                _commentsState.value = UiState.Success(updated)
                // Decrement the post's commentCount by the total number of
                // removed comments (parent + all nested replies, recursively).
                val removedCount = 1 + countNestedReplies(comment)
                val post = (_postState.value as? UiState.Success)?.data
                if (post != null) {
                    _postState.value = UiState.Success(
                        post.copy(commentCount = (post.commentCount - removedCount).coerceAtLeast(0))
                    )
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _events.tryEmit(e.message ?: "Could not delete comment.")
            }
        }
    }

    /** Recursively count a comment's nested replies (BFS). */
    private fun countNestedReplies(comment: CommentDto): Long {
        var count = 0L
        val queue = ArrayDeque<CommentDto>()
        queue.addAll(comment.replies)
        while (queue.isNotEmpty()) {
            val c = queue.removeFirst()
            count++
            queue.addAll(c.replies)
        }
        return count
    }

    fun sendComment(postId: String, content: String, parentCommentId: String? = null) {
        if (content.isBlank() || _isSendingComment.value) return
        viewModelScope.launch {
            _isSendingComment.value = true
            try {
                val newComment = repo.createComment(
                    postId = postId,
                    content = content,
                    parentCommentId = parentCommentId,
                )
                val current = (_commentsState.value as? UiState.Success)?.data
                if (current != null) {
                    if (parentCommentId != null) {
                        // Insert as a reply to the parent comment.
                        val updated = current.map { c ->
                            if (c.id == parentCommentId) {
                                c.copy(replies = c.replies + newComment)
                            } else c
                        }
                        _commentsState.value = UiState.Success(updated)
                    } else {
                        // Insert as a new top-level comment.
                        _commentsState.value = UiState.Success(listOf(newComment) + current)
                    }
                }
                _replyTarget.value = null
                // Update the post's comment count
                val post = (_postState.value as? UiState.Success)?.data
                if (post != null) {
                    _postState.value = UiState.Success(post.copy(commentCount = post.commentCount + 1))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Phase 2: surface the failure so the user can retry.
                _events.tryEmit("Could not post comment — please try again.")
            } finally {
                _isSendingComment.value = false
            }
        }
    }

    /**
     * Phase 2 — delete the post (author-only).
     *
     * Backend: `DELETE /api/v1/posts/{id}` (see
     * src/app/api/v1/posts/[id]/route.ts). The backend enforces
     * `requireVerifiedUser()` + ownership. Non-owners get 404 (the
     * backend deliberately does NOT leak existence to non-owners —
     * same pattern as the edit route).
     *
     * On success, sets [deleted] which the screen observes to pop
     * back to the previous screen (feed / profile / etc.).
     *
     * On failure, emits a snackbar event with the backend's error
     * message (e.g. "Post not found." on a 404, "You don't have
     * permission..." on a 403 — though the backend uses 404 to avoid
     * information disclosure).
     */
    fun deletePost(postId: String) {
        viewModelScope.launch {
            try {
                repo.deletePost(postId)
                _deleted.value = true
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _events.tryEmit(e.message ?: "Could not delete post.")
            }
        }
    }

    fun setReplyTarget(comment: CommentDto?) {
        _replyTarget.value = comment
    }
}
